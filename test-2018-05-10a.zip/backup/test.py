# import boto3
# import pyodbc


class Trace:

	def trace(self, message):
		if not hasattr(self, 'trace_flag'):
			self.trace_flag = False
		if self.trace_flag:
			print(message)

class Base:
	pass


class Test(Base, Trace):

	def __init__(self):
		self.trace_flag = True
		print('In init')
		self.trace('Tracing in init')

# testing multiple inheritance
# test = Test()


def get_line(lines):
	if lines:
		return lines.pop(0).strip().lower()
	else:
		return '#eof'


file_name = 'amp.def'
file_name = 'rtp.def'
with open(file_name) as input_stream:
	source = input_stream.read()
source = source.replace('[dbo].', '')
source = source.replace('[', '').replace(']', '')
source = source.replace('amp_IKON_', '')
lines = source.splitlines()

while True:
	line = get_line(lines)
	command = line.partition(' ')[0].lower()
	if command == 'create':
		table = line.split()[2].strip('(')
		columns = list()
		while True:
			line = get_line(lines)
			if line == '(':
				pass
			elif line.startswith((');', 'constraint')):
				break
			else:
				column = line.partition(' ')[0]
				columns.append(column)
		print(f'Table: {table}: {columns}')
	elif command == 'alter':
		pass
	elif command == '#eof':
		break




