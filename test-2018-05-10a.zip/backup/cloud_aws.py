#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
AWS abstracted cloud services.
"""


# cloud_aws.py

# standard libs
import json
import time
import urllib.parse

# 3rd party libs
import boto3

# udp libs
import config


class Connect:

	def __init__(self, resource_name, connection):
		# generic attributes
		self.client = None
		self.resource_type = ''
		self.resource_name = resource_name
		self.connection = connection

		# resource specific attributes
		self.object_store_name = ''
		self.queue_name = ''
		self.queue_url = ''
		self.queue_seen_messages = set()

		# setup and connect
		self.pre_connect()
		self.connect()
		self.post_connect()

	def pre_connect(self):
		pass

	def post_connect(self):
		pass

	# TODO: Logic to assume a role if non-empty role in connection object.
	def connect(self):
		# connect
		self.client = boto3.client(
			self.resource_type,
			aws_access_key_id=self.connection.public_key,
			aws_secret_access_key=self.connection.private_key,
			region_name=self.connection.region_name
		)


# https://boto3.readthedocs.io/en/latest/reference/services/s3.html
class ObjectStore(Connect):

	def pre_connect(self):
		self.resource_type = 's3'
		self.object_store_name = self.resource_name

	def put(self, file_name, object_key):
		# Filename=, Bucket=, Key=
		# uploads file using a multi-threaded, multi-part uploader
		self.client.upload_file(file_name, self.object_store_name, object_key)

	def get(self, file_name, object_key):
		# Bucket=, Key=, Filename=
		# downloads a file using a multi-threaded, multi-part downloader
		self.client.download_file(self.object_store_name, object_key, file_name)

	def delete(self, object_key):
		# Bucket=, Key=
		self.client.delete_object(Bucket=self.object_store_name, Key=object_key)


# https://boto3.readthedocs.io/en/latest/reference/services/sqs.html
class Queue(Connect):

	def pre_connect(self):
		self.resource_type = 'sqs'
		self.queue_name = self.resource_name

	def post_connect(self):
		# lookup queue url
		response = self.client.get_queue_url(QueueName=self.queue_name)
		self.queue_url = response['QueueUrl']

	def put(self, message):
		response = self.client.send_message(QueueUrl=self.queue_url, MessageBody=message, DelaySeconds=0)
		return response


	"""
	The receipt handle is associated with a specific instance of receiving the message. 

	If you receive a message more than once, the receipt handle you get each time you receive the message is different. 
	If you don't provide the most recently received receipt handle for the message when you use the DeleteMessage action, 
	the request succeeds, but the message might not be deleted.

	For standard queues, it is possible to receive a message even after you delete it.

	This might happen on rare occasions if one of the servers storing a copy of the message is unavailable when you send 
	the request to delete the message. The copy remains on the server and might be returned to you on a subsequent receive 
	request. You should ensure that your application is idempotent, so that receiving a message more than once does not 
	cause issues.
	"""
	def get(self):
		response = self.client.receive_message(
			QueueUrl=self.queue_url,
			MaxNumberOfMessages=1,
			MessageAttributeNames=['All'],
			VisibilityTimeout=0,
			WaitTimeSeconds=0
		)

		# track seen messages and ignore duplicate messages
		if response and 'Messages' in response:
			message_id = response['Messages'][0]['ReceiptHandle']
			if message_id in self.queue_seen_messages:
				response = None
			else:
				self.queue_seen_messages.add(message_id)

		return response

	def delete(self, message_id):
		if message_id:
			self.client.delete_message(QueueUrl=self.queue_url, ReceiptHandle=message_id)

	def list(self):
		response = self.client.list_queues()
		print(response)

	def dump(self):
		print(f'Queue: {self.queue_name} - {len(self.queue_seen_messages)}')
		for message_id in self.queue_seen_messages:
			print(f'Message: {message_id[0:8]}')


class ObjectStoreNotification:

	def __init__(self, response):
		self.message_id = ''
		self.message = ''
		self.ip_address = ''
		self.object_store_name = ''
		self.object_key = ''
		self.object_size = 0

		# get first message
		if not response or 'Messages' not in response:
			pass
		else:
			message = response['Messages'][0]['Body']
			self.message_id = response['Messages'][0]['ReceiptHandle']

			# url decode message contents
			# https://stackoverflow.com/questions/16566069/url-decode-utf-8-in-python/32451970
			message = urllib.parse.unquote(message)

			# convert message's first record to a notification dict
			if message:
				if not message.startswith(('"', '{', '[')):
					self.message = message
				else:
					body = json.loads(message)
					if 'Records' in body:
						notification = body['Records'][0]
						self.ip_address = notification['requestParameters']['sourceIPAddress']
						self.object_store_name = notification['s3']['bucket']['name']
						self.object_key = notification['s3']['object']['key']
						self.object_size = notification['s3']['object']['size']

			# TODO: Fix this "filter out S3 inventory file messages"
			if 'csv.gz' in self.object_key or 'inventory' in self.object_key:
				self.message_id = ''
				self.message = ''
				self.ip_address = ''
				self.object_store_name = ''
				self.object_key = ''
				self.object_size = 0

	def __str__(self):
		if self.message:
			return f'[id:{self.message_id[0:8]}] {self.message}'
		else:
			return f'[id:{self.message_id[0:8]}] {self.object_store_name}: {self.object_key} (size={self.object_size}, via {self.ip_address})'


# test code
def main():
	# test data
	connect_name = 'aws_amc_capture_dev'
	object_store_name = 'udp-s3-capture-amc-sandbox'
	queue_name = 'udp-sqs-capture-sandbox'

	# get connection info
	connect_config = config.Config('config/udp.connect', config.ConnectionSection)
	cloud_connection = connect_config.sections[connect_name]

	# object store put, get, delete
	object_store = ObjectStore(object_store_name, cloud_connection)
	object_store.put('test1.data', 'test/test1.data')
	object_store.get('test2.data', 'test/test1.data')
	object_store.delete('test/test1.data')

	# sleep for 3 seconds to give notification message time to post to queue
	time.sleep(3)

	# queue get, remove
	queue = Queue(queue_name, cloud_connection)
	queue.put('Test message 1')
	time.sleep(2)
	queue.put('Test message 2')
	time.sleep(2)
	while True:
		time.sleep(1)
		response = queue.get()
		notification = ObjectStoreNotification(response)
		queue.delete(notification.message_id)
		if notification.message_id:
			print(notification)
		else:
			break

	# debugging info
	queue.dump()


# test code
if __name__ == '__main__':
	main()
