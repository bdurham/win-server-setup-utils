# scrub_sql_for_table_names.py

"""
Extract table names from specified SQL scripts

"""

script_files = '''
/Users/malcolmgreene/Downloads/Intrawest/2018-04-16 v_CustomerProfile Create Script.sql
/Users/malcolmgreene/Downloads/Intrawest/2018-04-16 v_PbiActg Create Script.sql
/Users/malcolmgreene/Downloads/Intrawest/2018-04-16 v_PbiSls Create Script.sql
/Users/malcolmgreene/Downloads/Intrawest/2018-04-16 v_PbiSlsBudgetDaily Create Script.sql
/Users/malcolmgreene/Downloads/Intrawest/2018-04-17 v_PbiSlsDemo Create Script.sql
'''.strip().splitlines()

def word_following(keyword, text):
	before, keyword, after = text.lower().partition(keyword.lower())
	if after:
		after = after.split()[0].replace('..', '.')
	if after.startswith('('):
		after = ''

	return after


def parse_file_for_table_names(file_name, tables):
	with open(file_name, encoding='iso8859') as input_stream:
		for line in input_stream:
			# normalize line
			line = (' ' + line.replace('\t', ' ') + ' --').lower()

			# remove comments
			line, comment_marker, comment = line.partition('--')

			# take first word following from
			from_table = word_following('from', line)
			if from_table:
				tables.append(from_table)
			join_table = word_following('join', line)
			if join_table:
				tables.append(join_table)


# test code
def main():
	tables = list()
	for file_name in script_files:
		parse_file_for_table_names(file_name, tables)

	print(f'Extracted table names ({len(set(tables))}):')
	for table in sorted(set(tables)):
		print(table)

# test code
if __name__ == '__main__':
	main()

