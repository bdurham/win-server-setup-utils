#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Capture
"""


# standard libs
import copy
import datetime
import glob
import json
import os
import pathlib
import pickle
import shutil
import sys
import time

# udp libs
import app
import cloud_aws as cloud
import config
import daemon
import database


def expand(expression):
	# reach up call stack to get callers locals() dict

	# noinspection PyProtectedMember
	caller_locals = sys._getframe(1).f_locals
	triple_quote = "'" * 3
	return eval(f'f{triple_quote}{expression}{triple_quote}', None, caller_locals)


def json_extended(obj):
	"""JSON serializer for objects not serializable by default json code"""
	if isinstance(obj, (datetime.datetime, datetime.date)):
		return obj.isoformat()
	else:
		raise TypeError ("Type %s not serializable" % type(obj))


# job.ini - job_id counter and last_run_time for range checks
# allow last_run_time to be overridden for new tables being onboarded

# table definition parser - need a test mode as well
# .name
# .create
# .pull (capture, extract, ...) - SQL with <job>, <pk>, <timestamp> markers ???
# .pk (expression)
# .timestamp (expression)
# .columns (pulled from create)
# .types (pulled from create)
# .starttime (initial start time, used if table.history doesn't have table reference)
# .namespace (pulled from parent folder)


'''
job.ini - job counter
history.ini - tracks tables that have been successfully pulled along with time of first pull; remove to re-pull

'''


class Stat:

	def __init__(self, stat_name):
		self.stat_name = stat_name
		self.start_time = None
		self.end_time = None
		self.run_time = 0
		self.record_count = 0
		self.file_size = 0

	def start(self):
		self.start_time = datetime.datetime.now()

	def stop(self, record_count=0, file_size=0):
		self.end_time = datetime.datetime.now()
		self.run_time = (self.end_time - self.start_time).total_seconds()
		self.record_count = record_count
		self.file_size = file_size

	def log(self):
		return f'{self.stat_name}, {self.start_time}, {self.end_time}, {self.run_time}, {self.record_count}, {self.file_size}'


class Stats:

	def __init__(self):
		self.stats = dict()

	def start(self, stat_name):
		self.stats[stat_name] = Stat(stat_name)
		self.stats[stat_name].start()

	def stop(self, stat_name, record_count=0, file_size=0):
		self.stats[stat_name].stop(record_count, file_size)

	def log(self):
		# make name and path of log output an option
		# also allow saving in a json vs csv format (with column header row)
		with open('stats.log', 'w') as output_stream:
			output_stream.write('stat_name, start_time, end_time, run_time, record_count, file_size\n')
			for stat_name, stat in self.stats.items():
				output_stream.write(stat.log() + '\n')

# updated capture
def capture():
	pass

	# SETUP

	# read config files based on parent folder name = namespace
	# namespace.project, connect.library (udp.connect), namespace.tables

	# create if missing: history, capture, landing folders

	# create if missing: capture.session, capture.job (jobid, last_timestamp)
	# create if missing: capture.history (table_name, last_timestamp, last_rowversion, last_filehash)

	# session_log = log( 'session', session_id )

	# CAPTURE LOOP (within exception block)
	# for table in namespace.tables

	# load capture.job
	# load capture.history
	# load

	# build cdc type select
	# capture data to json file format or pickle file format (temp)
	# column names, types, rows of data
	# rows = [ tuple(row) for row in cursor.fetchall() ]

	# STAGING NOTE:
	# create target table
	# load target rows as a batch or in multiple batches
	# mysql (MySQLdb) placeholder = %s
	# mssql (pyodbc) placeholder = ?
	# postgresql (psycopg2) placeholder = %s; %(name)s if row passed as dict with keys=name
	# if dict: %(num)d, %(text)s where num and text are key names, rows are dict
	# postgresql executemany advice: https://stackoverflow.com/questions/8134602/
	# postgresql - use execute_values() via http://initd.org/psycopg/docs/extras.html#fast-exec !!!!
	#
	# sql = 'insert into <table_name> (<column_names>) values (<placeholders>)'
	# conn.cursor.executemany( sql, rows )
	# conn.commit()
	# conn.close() when done

	# copy .project, .tables, .change to capture folder
	# copy .job, .history, .log (capture, last_capture) to capture folder

	# if successful:
	# - update capture.job (jobid ++, last_timestamp = current_timestamp
	# - update capture.history (table_name, last*)
	# - save job_log.save( history/last_capture.log)
	# - update


	# CLEANUP

	# session_event.stop( )
	# session_event.save( 'session.log' ) <---

	# ARCHIVE NOTES
	# - if present, load and merge last_capture.log into job_log (adds compress time/siz

	# STAGE NOTES
	# -

#
def main():
	# read config files

	# constants
	landing_folder = 'landing'

	# connection info
	connect_config = config.Config('config/udp.connect', config.ConnectionSection)
	connect_config.dump()

	# project - amp, dlakeref, rtp
	project_name = 'amp'
	project_config = config.Config(f'config/{project_name}.project', config.ProjectSection)
	project_config.dump()
	project_object = project_config.sections['project']

	namespace = f'{project_object.entity}_{project_object.location}_{project_object.system}_{project_object.instance}_{project_object.subject}'
	print(f'Namespace: {namespace}')

	# table info
	table_config = config.Config(f'config/{project_name}.table', config.TableSection)
	table_config.dump()

	# source database info
	database_connect_name = project_object.database
	database_connect = connect_config.sections[database_connect_name]
	schema_name = database_connect.schema

	# cloud connection
	cloud_connect_name = project_object.cloud
	cloud_connection = connect_config.sections[cloud_connect_name]

	# establish cloud connection
	# udp-s3-capture-amc-sandbox
	# TODO: Rename s3 location (resort) bucket to match udp-aws-s3-<location>-<sdlc>
	# capture_objectstore_name = f'udp-s3-capture-{project_object.entity}-{project_object.sdlc}'
	capture_objectstore_name = f'{project_object.capture_objectstore}-{project_object.entity}-{project_object.sdlc}'
	print(f'capture_objectstore: {capture_objectstore_name}')

	# 2018-05-03 testing
	# capture_objectstore_name = f'aws-udp-s3-capture-amc-{project_object.sdlc}'
	# s3_client = boto3.client('s3', aws_access_key_id=aws_connect.public_key, aws_secret_access_key=aws_connect.private_key, region_name=aws_connect.region_name)
	capture_objectstore = cloud.ObjectStore(capture_objectstore_name, cloud_connection)

	# job info
	job_config = config.Config(f'config/{project_name}.job', config.JobSection)
	job_object = job_config.sections['job']
	job_id = int(job_object.job_id)

	# SQL templates
	sql_config = config.ConfigSectionValue(f'config/capture.sql')

	# connect to source database
	debug = True
	db_conn = None
	if database_connect.engine == 'postgresql':
		db = database.PostgreSQLConnection(database_connect, debug)
		db_conn = database.Database('postgresql', db.conn)
	elif database_connect.engine == 'sqlserver':
		db = database.SQLServerConnection(database_connect, debug)
		db_conn = database.Database('sqlserver', db.conn)

	conn = db.conn
	cursor = conn.cursor()

	# capture loop - refactor to separate function/method
	last_timestamp = None
	current_timestamp = None
	while True:

		# TODO: save in *.job file with other job stat values; see notes
		job_id = job_id + 1
		job_name = f'job_{job_id}'

		print('Running job: {job_name} ...')

		stats = Stats()
		stats.start(job_name)

		# clear landing folder
		# for file_name in glob.glob('{landing_folder}/*'):
		for file_name in glob.glob('landing/*'):
			# print(f'Deleting: {file_name}')
			os.remove(file_name)

		for table_name, table_object in table_config.sections.items():
			# skip default table
			if table_name == 'default':
				continue

			stats.start(table_name)
			print(f'Processing {table_name} ...')

			# save schema for stage to use
			table_schema = db_conn.select_table_schema('public', table_name)
			output_stream = open(f'{landing_folder}/{table_name}.schema', 'wb')
			pickle.dump(table_schema, output_stream)
			output_stream.close()


			# discover schema
			# sql_command = sql_config.sections['table_schema_query']
			# cursor.execute('{sql_command}')
			# column = dict()
			# for row in cursor.fetchall():
			# 	column[row.column_name] = copy.deepcopy(row)
			#
			# # discover primary keys
			# # TODO: This should be database object specific vs conditional
			# if database_connect.engine == 'postgresql':
			# 	sql_command = sql_config.sections['postgresql_primary_key_query']
			# else:
			# 	sql_command = sql_config.sections['sqlserver_primary_key_query']
			# cursor.execute('{sql_command}')
			# pk_expression = ', '.join([row.column_name for row in cursor.fetchall()])

			# run extract dependent on cdc type
			source_columns = '*'
			cdc_columns = 'updated_at as udp_timestamp'
			udp_columns = '{job_id} as udp_jobid'
			# sql_command = expand(sql_config.sections['data_capture_query_basic'])

			# TEST: Test cloud - not CDC extract logic which needs further testing/tuning/optimization.
			# sql_command = f'select * from {table_name} limit 100;'
			# cursor.execute(sql_command, None)

			column_names = table_schema.columns.keys()
			cursor = db_conn.capture_select(schema_name, table_name, column_names, last_timestamp, current_timestamp)

			# save data in json format
			json_rows = list()

			# only process cursor if we have data
			for row in cursor.fetchall():
				# save to json vs csv to preserve nulls
				json_rows.append(row)

			output_file = f'{landing_folder}/{table_name}.json'
			with open(output_file, 'w') as output_stream:
				# indent=2 for debugging
				json.dump(json_rows, output_stream, indent=2, default=json_extended)

			stats.stop(table_name, len(json_rows), os.path.getsize(output_file))

		# stop job stats and save stats in compressed file send
		stats.stop(job_name)
		stats.log()

		# compress landing files
		stats.start('compress')
		base_name = f'{landing_folder}/{namespace}-{job_id}'
		print('Starting capture compression ...')
		capture_file_name = shutil.make_archive(base_name, format='zip', root_dir=landing_folder)
		print('Completed capture compression')
		capture_file_name = pathlib.Path(capture_file_name).name
		zip_file_size = os.path.getsize(f'{base_name}.zip')
		stats.stop('compress', 0, zip_file_size)

		# upload to s3
		s3_file_name = f'{namespace}/{capture_file_name}'
		print(f's3 bucket: {capture_objectstore_name}; s3 filename: {s3_file_name}')

		# .upload_file() is a managed uploader that splits files and uploads in parallel
		stats.start('s3_upload')
		# s3_client.upload_file(f'{landing_folder}/{capture_file_name}', s3_bucket_name, s3_file_name)
		print('Starting upload to objectstore ...')
		capture_objectstore.put(f'{landing_folder}/{capture_file_name}', s3_file_name)
		print('Completed upload to objectstore')
		stats.stop('s3_upload')

		# save final full stat log
		stats.stop(job_name)
		stats.log()

		# TODO: Drive by project config file polling value
		# TODO: Replace time with scheduler and source database clock vs server clock values
		# TODO: Sungard VM's have clock drift - must sync from database time to be accurate
		print('Waiting for next capture cycle ...')
		time.sleep(30)


# main
if __name__ == '__main__':
	# TODO: wrap in app, daemon, scheduler class wrappers for NT Service
	main()
