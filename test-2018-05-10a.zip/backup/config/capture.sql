# capture.sql

This should be an error.


# query information schema for table attributes
[table_schema_query]
select {schema_columns}
  from information_schema.columns
  where
    table_schema = '{schema_name}' and
    table_name = '{table_name}';





# query
[data_capture_query_basic]

select {source_columns}, {cdc_columns}, {udp_columns}
  from {table_name} s
  where {timestamp_condition};

# query for multiple timestamps
# TODO: Use as pattern for multiple rowversions
# TODO: "select max(v) should be generated based on count of timestamps"
[data_capture_query_multi_timestamp]
-- (select ...) expression can be used in where and order by
select
  *,
  (select max(v) from (values (val_1), (val_2), (val_3), (val_4)) as value(v)) as max_value
  from {table_name} s
  where {timestamp_condition};


[table_schema_discovery]
select
  data_type,
  character_maximum_length, -- null, -1 (=max), specific length
  numeric_precision,
  numeric_scale,
  datetime_precision,       -- date=0; datetime=3; smalldatetime=0; time=7, timestamp=Null;
  datetime_precision,       -- (PostgreSQL) - timestamp without time zone=6
  character_set_name,       -- char, text, varchar=iso_1; nchar, nvarchar=UNICODE
  collation_name            -- char, nchar, nvarchar, text, varchar=SQL_Latin1_General_CP1_CI_AS
  from information_schema.tables
  where
    table_schema = '{schema_name}' and
    table_name = '{table_name}';


[postgresql_primary_key]
-- column names, one per row, that comprise a table's primary key
select a.attname as column_name
    from pg_index i
    join pg_attribute a
        on a.attrelid = i.indrelid and a.attnum = any(i.indkey)
    where
        i.indrelid = 'public.{table_name}'::regclass and
        i.indisprimary
    order by column_name;


[sqlserver_primary_key]
select column_name
    from information_schema.constraint_column_usage
    where
        table_name = '{table_name}' and
        constraint_name LIKE 'PK%'
    order by column_name;

