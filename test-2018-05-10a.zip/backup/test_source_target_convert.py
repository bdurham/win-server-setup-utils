# test_source_target_convert.py

import database
import json
import sys


def expand(expression):
	# reach up call stack to get callers locals() dict

	# noinspection PyProtectedMember
	caller_locals = sys._getframe(1).f_locals
	triple_quote = "'" * 3
	return eval(f'f{triple_quote}{expression}{triple_quote}', None, caller_locals)




sql_table_schema = '''
select
    column_name,
    ordinal_position,
    is_nullable,
    data_type,
    character_maximum_length,
    numeric_precision,
    numeric_scale,
    datetime_precision,
    character_set_name,
    collation_name
  from
    information_schema.columns
  where
    table_schema = 'public' and
    table_name = '{table_name}' and
    table_name not like 'pg_%'
  order by ordinal_position;
'''


class TableSchema:

	def __init__(self):
		self.source_columns = list()
		self.target_columns = list()

	def column(self, row):
		column = dict()
		column['column_name']= row.column_name
		column['ordinal_position'] = row.ordinal_position
		column['is_nullable'] = row.is_nullable
		column['data_type'] = row.data_type
		column['character_maximum_length'] = row.character_maximum_length
		column['numeric_precision'] = row.numeric_precision
		column['numeric_scale'] = row.numeric_precision
		column['datetime_precision'] = row.datetime_precision
		column['character_set_name'] = row.character_set_name
		column['self.collation_name'] = row.collation_name
		self.source_columns.append(column)

	def source_schema(self):
		'''Raw source column attributes'''
		return json.dumps(self.source_columns)

	def target_schema(self):
		'''Source column attributes translated to target database'''
		pass

class TableSchemaPostgreSQL(TableSchema):

	# TODO: Add from casts; to casts are dependent on target data type
	# TODO: When source cast/expression add ... ' as <column_name>' to preserve column naming
	# TODO: Add target_schema to create table
	# TODO: Accept optional default size, size overrides, profile plus power of 2 or percent multiplier

	def target_schema(self):
		for column in self.source_columns:
			column_name = column['column_name'].lower()
			data_type = column['data_type'].lower()
			cast = ''

			if data_type == 'array':
				from_cast = f'cast({column_name} as text)'
				data_type = 'varbinary'
				size = 0

			elif data_type == 'bigint':
				data_type = 'bigint'

			elif data_type == 'boolean':
				cast = f'cast({column_name} as integer)'
				data_type = 'bit'

			elif data_type == 'character varying':
				data_type = 'nvarchar'
				size = 0

			elif data_type == 'date':
				data_type = 'date'

			elif data_type == 'integer':
				data_type = 'int'

			elif data_type == 'jsonb':
				data_type = 'varbinary'
				size = 0

			elif data_type == 'text':
				data_type = 'nvarchar'
				size = 0

			elif data_type == 'timestamp without time zone':
				data_type = 'datetime2'
				datetime_scale = 7

			elif data_type == 'user - defined':
				data_type = 'nvarchar'
				size = 0

			elif data_type == 'uuid':
				data_type = 'char'
				size = 36

			else:
				# raise unknown source data type exception
				pass


def table_source_schema(conn, table_name):
	cursor = conn.cursor()
	sql = expand(sql_table_schema)
	cursor.execute(sql)
	table_schema = TableSchema()
	for column_definition in cursor.fetchall():
		table_schema.column(column_definition)
	print(table_schema.source_schema())


# test code
def main():
	# PostgreSQL
	host_name = 'ec2-34-230-153-80.compute-1.amazonaws.com'
	database_name = 'dcdc9r2tplv9f'
	user_name = 'alterra-data-lake-uat'
	password = 'p933dbd025533bd4a7bfb4cb53a7bf16bac7112926df2d853e91a21beb951efc2'

	db = database.PostgreSQLConnection(host_name, database_name, user_name, password, debug=True)
	conn = db.conn

	table_source_schema(conn, 'guests')


# test code
if __name__ == '__main__':
	main()

