#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Common code.

TODO: Consolidate common code across modules here.
TODO: This will become udp_common.py
"""


# common.py
import os


# noinspection PyUnresolvedReferences
env_info = f'''
User: {os.getlogin()}
Server: {os.uname().nodename}
OS: {os.uname().sysname} {os.uname().release}
'''.strip()

print(env_info)
