#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Config module used to read the following operator editable files:

Project folder specific
- capture.project
- capture.table (table descriptions)
- capture.change (change management)
- capture.schedule (scheduling times synced to source database server clock/timestamps)

Global
- udp.connect (named connections)
- capture.sql
- archive.sql
- stage.sql
- <database>.sql (postgresql, sqlserver)

The following are stored as readable but not editable JSON files
- capture.history (job id, job runtime; table history (last_*), source schemas)


Todo: Refactor this logic as a re-usable function or method?
# normalize whitespace
line = line.replace('\t', ' ')

# strip off trailing // comments
line = (line + '//').partition('//')[0].rstrip()


"""

# config.py
import copy
import sys


class ConfigSection:

	def dump(self):
		for key in self.__dict__:
			value = getattr(self, key, '')
			if value and not key.startswith('_'):
				print(f'{key} = {value}')


class Config:

	def __init__(self, file_name, section_class):
		self.comment_chars = ('#', ';', '//')
		self.file_name = file_name
		self.section_class = section_class
		self.sections = dict()
		self.load()

	def error(self, line_number, message):
		print(f'Warning: {self.file_name}[{line_number}]: {message}')

	def is_section(self, line):
		if not(line.startswith('[') and line.endswith(']')):
			section_status = False
		else:
			section_status = line.count('[') == 1 and line.count(']') == 1
		return section_status

	def is_comment(self, line):
		return line.strip().startswith(self.comment_chars)

	def is_assignment(self, line):
		name, separator, value = line.partition('=')
		name = name.strip().lower()
		return name and ' ' not in name and separator == '='

	def get_assignment(self, line):
		name, separator, value = line.partition('=')
		name = name.strip().lower()
		value = value.strip()
		return name, value

	def load(self):
		with open(self.file_name) as input_stream:
			section_object = None
			name = ''
			for line_number, line in enumerate(input_stream, 1):
				# normalize whitespace
				line = line.replace('\t', ' ')

				# strip off trailing // comments
				line = (line + '//').partition('//')[0].rstrip()

				if not line.strip() or self.is_comment(line):
					# ignore comments and blank lines and reset current property name
					name = ''

				elif self.is_section(line):
					# new section (or redefined section)

					# reset current property name
					name = ''

					section_name = line.lstrip('[').rstrip(']').strip().lower()
					if not section_name:
						self.error(line, 'Empty section name')
					else:
						# if a default section exists, use a copy of it as new section object
						if 'default' in self.sections:
							section_object = copy.deepcopy(self.sections['default'])
						else:
							section_object = self.section_class()
						self.sections[section_name] = section_object

				elif self.is_assignment(line) and section_object:
					# assignment
					name, value = self.get_assignment(line)

					if name.strip().lower() == 'clone':
						clone_name = value.strip().lower()
						if clone_name in self.sections:
							section_object = copy.deepcopy(self.sections[clone_name])
							self.sections[section_name] = section_object
						else:
							self.error(line_number, f'Unknown clone reference ({clone_name})')

					elif not hasattr(section_object, name):
						self.error(line_number, f'Unknown property ({name})')
					else:
						setattr(section_object, name, value)

				else:
					if not(section_object and name):
						self.error(line_number, 'Line without assignment')
					else:
						value = getattr(section_object, name)
						if value.startswith('\\'):
							setattr(section_object, name, value + '\n' + line)
						else:
							self.error(line_number, 'Line without assignment')

	def dump(self):
		print(f'\n\nFile: {self.file_name}\n')
		for section_name in self.sections:
			print(f'[{section_name}]')
			section_object = self.sections[section_name]
			section_object.dump()
			print()


class ProjectSection(ConfigSection):

	def __init__(self):
		# self._section_name = 'project_name'
		self.project_name = ''
		self.entity = ''
		self.location = ''
		self.system = ''
		self.instance = ''
		self.subject = ''
		self.sdlc = ''

		self.polling = ''

		self.database = ''

		self.cloud = ''
		self.capture_objectstore = ''
		self.archive_objectstore = ''
		self.capture_queue = ''
		self.archive_queue = ''
		self.stage_queue = ''


class Capture_Project(ConfigSection):

	def __init__(self):
		# self._section_name = 'project_name'
		self.project_name = ''
		self.entity = ''
		self.location = ''
		self.system = ''
		self.instance = ''
		self.subject = ''
		self.sdlc = ''

		self.cloud = ''
		self.database = ''
		self.capture_objectstore = ''


"""
Future: Column specific overrides for target staging column attributes

Examples:
- column:name_on_card = nvarchar(64)
- column:year = char(4)
- column:card_type = char(8)

Optionally
- set default size (length) for un-sized source columns, eg. 255.
- automatically profile source data and suggest target column sizes (lengths)
"""

class TableSection(ConfigSection):

	def __init__(self):
		self._section_name = 'table_name'
		self.table_name = ''
		self.table_prefix = ''
		self.table_suffix = ''
		self.natural_key = ''
		self.cdc = ''
		self.timestamp = ''
		self.first_timestamp = ''
		self.rowversion = ''
		self.first_rowversion = ''
		self.select = ''
		self.ignore = ''


class ChangeSection(ConfigSection):

	def __init__(self):
		pass


class ConnectionSection(ConfigSection):

	def __init__(self):
		self._section_name = 'connection_name'
		self.connection_name = ''

		# cloud connections - aws specific
		self.region = ''
		self.role = ''
		self.publickey = ''
		self.privatekey = ''

		# database connections - all databases
		self.engine = ''
		self.driver = ''
		self.host = ''
		self.port = ''
		self.database = ''
		self.schema = ''
		self.username = ''
		self.password = ''


class JobSection(ConfigSection):

	def __init__(self):
		self._section_name = 'job_name'
		self.job_name = ''
		self.job_id = ''


class ConfigSectionValue:

	"""Capture values at the [section] vs [section].property = value level"""

	def __init__(self, file_name):
		self.comment_chars = ('#', ';', '//')
		self.file_name = file_name
		self.sections = dict()
		self.load()

	def error(self, line_number, message):
		print(f'Warning: {self.file_name}[{line_number}]: {message}')

	def is_section(self, line):
		if not(line.startswith('[') and line.endswith(']')):
			section_status = False
		else:
			section_status = line.count('[') == 1 and line.count(']') == 1
		return section_status

	def is_comment(self, line):
		return line.strip().startswith(self.comment_chars)

	def load(self):
		with open(self.file_name) as input_stream:
			section_name = ''
			for line_number, line in enumerate(input_stream, 1):
				# normalize whitespace
				line = line.replace('\t', ' ')

				# strip off trailing // comments
				line = (line + '//').partition('//')[0].rstrip()

				# skip comment lines, but pass blank lines through as data
				if line.startswith(self.comment_chars):
					continue

				# start a new section
				elif line.startswith('[') and line.endswith(']'):
					section_name = line.lstrip('[').rstrip(']').strip().lower()
					self.sections[section_name] = ''

				# add line to section's value
				elif section_name:
					self.sections[section_name] += '\n' + line.rstrip()

				# non-blank lines without a section name are treated as errors
				elif line:
					self.error(line_number, 'Unexpected line outside of defined section')

		# strip leading and trailing whitespace from values
		# Note: This does not effect indented values.
		for section_name in self.sections:
			self.sections[section_name] = self.sections[section_name].strip()

	def dump(self):
		print(f'\n\nFile: {self.file_name}\n')
		for section_name, section_value in self.sections.items():
			print(f'[{section_name}]\n{section_value}\n')


# test code
def main():
	connect_config = Config('config/udp.connect', ConnectionSection)
	connect_config.dump()

	project_config = Config('config/amc_heroku_amp_01_sales_dev.project', ProjectSection)
	project_config.dump()
	table_config = Config('config/amc_heroku_amp_01_sales_dev.tables', TableSection)
	table_config.dump()
	project_config = Config('config/amc_sungard_dlakeref_01_sales_dev.project', ProjectSection)
	project_config.dump()
	table_config = Config('config/amc_sungard_dlakeref_01_sales_dev.tables', TableSection)
	table_config.dump()
	project_config = Config('config/amc_sungard_rtp_01_sales_dev.project', ProjectSection)
	project_config.dump()
	table_config = Config('config/amc_sungard_rtp_01_sales_dev.tables', TableSection)
	table_config.dump()

	project_config = Config('config/udp_aws_archive_01_etl_dev.project', ProjectSection)
	project_config.dump()
	project_config = Config('config/udp_aws_stage_01_etl_dev.project', ProjectSection)
	project_config.dump()

	# TODO: support ValueSection parsing
	sql_config = ConfigSectionValue('config/capture.sql')
	sql_config.dump()


# test code
if __name__ == '__main__':
	main()
	sys.exit()
