#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Module comment here ...
"""


# module name here ...
import os

# retrieve secret settings from env variables
# migrate to named connection
db_server = os.getenv('<prefix>_DB_SERVER')
db_user = os.getenv('<prefix>_DB_USER')
db_pass = os.getenv('<prefix>_DB_PASS')


# job.ini - job_id counter and last_run_time for range checks
# allow last_run_time to be overridden for new tables being onboarded

# table definition parser - need a test mode as well
# .name
# .create
# .pull (capture, extract, ...) - SQL with <job>, <pk>, <timestamp> markers ???
# .pk (expression)
# .timestamp (expression)
# .columns (pulled from create)
# .types (pulled from create)
# .starttime (initial start time, used if table.history doesn't have table reference)
# .namespace (pulled from parent folder)


'''
job.ini - job counter
history.ini - tracks tables that have been successfully pulled along with time of first pull; remove to re-pull

'''


# test code
def main():
	pass


# test code
if __name__ == '__main__':
	main()
