#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Test AWS S3 connection, S3 file upload and tag.
"""


# test_aws_s3_upload_and_tag.py
import arrow
import boto3
import datetime
import json
import sys
import time
import urllib.parse

class Object:
	pass

def time_delta_units(time_delta):
	days = time_delta.days
	hours, remainder = divmod(time_delta.seconds, 3600)
	minutes, seconds = divmod(remainder, 60)
	print(days, hours, minutes,seconds)
	return days, hours, minutes, seconds

# key_value_str = f'udp_resort={resort_code}; udp_role=capture; udp_version=1.2.3a'
def make_tags(key_value_str):
	key_value_pairs = key_value_str.split(';')
	key_value_list = list()
	for key_value_pair in key_value_pairs:
		key, separator, value = key_value_pair.partition('=')
		key = key.strip().lower()
		value = value.strip().lower()
		key_value_dict = {'Key':key, 'Value':value}
		key_value_list.append(key_value_dict)

	aws_tag_dict = dict()
	aws_tag_dict['TagSet'] = key_value_list
	return aws_tag_dict

'''
# sender account id: AIDAJVEO32BJMF27H2JKW - s3 client session
# sender account id: AIDAIFA34LTMMVSDJP5KQ - sqs client session

sts = boto3.client(
	'sts',
    aws_access_key_id=aws_public_key,
    aws_secret_access_key=aws_private_key,
	region_name=aws_region_name
)

user_name = sts.get_caller_identity()

					user_name = {'UserId': 'AIDAIFA34LTMMVSDJP5KQ', 'Account': '972075772547', 'Arn': 'arn:aws:iam::972075772547:user/udp-admin' ...}

'''

aws_region_name = 'us-west-2'
aws_public_key = 'AKIAJYD3U7KONQXEGIVQ'
aws_private_key = 'zQKB7xyKCWFDrkajgVpI2CtIzCFnEp/TbtOkhYoq'
sdlc_env = 'sandbox'

# namespace = <resort> - <system><instance or version as ##> - <subject>
resort_code = 'amc'
system_code = 'rtp'
system_instance = '01'
subject = 'sales'
namespace = f'{resort_code}-{system_code}{system_instance}-{subject}'

timestamp = arrow.now().format('YYYY-MM-DDTHH-mm-ss')
file_name = f'capture-{namespace}-{timestamp}.zip'
bucket_name = f'udp-s3-capture-{resort_code}-{sdlc_env}'
bucket_prefix = f'{namespace}'
bucket_file_name = f'{bucket_prefix}/{file_name}'

print(f'File name: {file_name}')
print(f'Bucket name: {bucket_name}')
print(f'Bucket prefix: {bucket_prefix}')

# create the test file
with open(file_name, 'w') as output_stream:
	output_stream.write('Test file')

session = boto3.Session(
    aws_access_key_id=aws_public_key,
    aws_secret_access_key=aws_private_key,
	region_name=aws_region_name
)

s3 = boto3.client(
	's3',
    aws_access_key_id=aws_public_key,
    aws_secret_access_key=aws_private_key,
	region_name=aws_region_name
)

# uploads file using a multi-threaded, multi-part uploader
s3.upload_file(file_name, bucket_name, bucket_file_name)

# tags are a dict['TagSet'] = list( key:value ) pairs
# TODO: Make this a function that takes key:value pair string and creates dict with list of key value tags
# tags = 'udp_resort:{resort_code}; udp_role:capture; udp_version:1.2.3a'
file_tags = {
	'TagSet':[
		{
			'Key': 'udp_resort',
			'Value': resort_code
		},
		{
			'Key': 'udp_role',
			'Value': 'capture'
		},
		{
			'Key': 'udp_version',
			'Value': '1.2.3a'
		}
	]
}

# best-practice: get tags and merge updated key:value pairs
response = s3.put_object_tagging(
    Bucket=bucket_name,
    Key=bucket_file_name,
    Tagging= file_tags
)

print(f'Response VersionId = {response["VersionId"]}')
print(f'{file_tags}')

key_value_str = f'udp_resort={resort_code}; udp_role=capture; udp_version=1.2.3a'
print(f'{make_tags(key_value_str)}')


'''
# get list of bucket names
response = s3.list_buckets()
buckets = [bucket['Name'] for bucket in response['Buckets']]
print("Bucket List: %s" % buckets)
'''

# downloads a file using a multi-threaded, multi-part download
# TODO: Make this a function
local_file_name = 's3_download.zip'
with open(local_file_name, 'wb') as output_stream:
	s3.download_fileobj(bucket_name, bucket_file_name, output_stream)


# poll for SQS messages

json_message = """
{
  "Records": [
    {
      "eventVersion": "2.0",
      "eventSource": "aws:s3",
      "awsRegion": "us-west-2",
      "eventTime": "2018-03-13T16:17:48.639Z",
      "eventName": "ObjectCreated:Put",
      "userIdentity": {
        "principalId": "AWS:AIDAIFA34LTMMVSDJP5KQ"
      },
      "requestParameters": {
        "sourceIPAddress": "73.14.78.86"
      },
      "responseElements": {
        "x-amz-request-id": "2D9466ECCFD9D638",
        "x-amz-id-2": "Il+9Y26TWewPuJm4FrNf20rykk+kVdF5OBkAWSoCDj/B9OubTqxNbojQOLY1FRUrAQ7M6P66juc="
      },
      "s3": {
        "s3SchemaVersion": "1.0",
        "configurationId": "udp-s3-capture-amc-sandbox-objectcreate",
        "bucket": {
          "name": "udp-s3-capture-amc-sandbox",
          "ownerIdentity": {
            "principalId": "A2MJ3NL0XBNJ0"
          },
          "arn": "arn:aws:s3:::udp-s3-capture-amc-sandbox"
        },
        "object": {
          "key": "amc-rtp01-sales/capture-amc-rtp01-sales-2018-03-01-16-00.zip",
          "size": 9,
          "eTag": "edc900745c5d15d773fbcdc0b376f00c",
          "versionId": "1OOeWxdo4gQ0fye_i5W_GNU.Ol_HOmKM",
          "sequencer": "005AA7F9ABC9CF642A"
        }
      }
    }
  ]
}
"""

json_object = json.loads(json_message)
print(f'json_object: {json_object}')

event_dict = json_object['Records'][0]
s3_dict = event_dict['s3']
print(event_dict['eventSource'])
print(event_dict['awsRegion'])
print(event_dict['eventTime'])
print(event_dict['eventName'])
print(event_dict['requestParameters']['sourceIPAddress'])
print(s3_dict['bucket']['name'])
print(s3_dict['object']['key'])
print(s3_dict['object']['size'])

# 2018-03-13T16:17:48.639Z
event_time = event_dict['eventTime']
arrow_datetime = arrow.get(event_time)
print(event_time)
print(arrow_datetime)

duration = arrow.now()-arrow_datetime
print(time_delta_units(duration))


# SQS test
# https://boto3.readthedocs.io/en/latest/guide/sqs-example-using-queues.html

sqs = boto3.client(
	'sqs',
    aws_access_key_id=aws_public_key,
    aws_secret_access_key=aws_private_key,
	region_name=aws_region_name
)

del response
response = sqs.list_queues()
print(response)

queue_name = 'udp-sqs-capture-sandbox'
response = sqs.get_queue_url(QueueName=queue_name)
queue_url = response['QueueUrl']
print(f'queue_url = {queue_url}')

response = sqs.receive_message(
  QueueUrl=queue_url,
  MaxNumberOfMessages=1,
  MessageAttributeNames=['All'],
  VisibilityTimeout=0,
  WaitTimeSeconds=0
)

message = response['Messages'][0]

# url decode
# https://stackoverflow.com/questions/16566069/url-decode-utf-8-in-python/32451970
json_message = message['Body']
json_message = urllib.parse.unquote(json_message)
# print(f'json_message = {json_message}')

json_object = json.loads(json_message)
# print(f'json_object: {json_object}')

event_dict = json_object['Records'][0]
s3_dict = event_dict['s3']
print(event_dict['eventSource'])
print(event_dict['awsRegion'])
print(event_dict['eventTime'])
print(event_dict['eventName'])
print(event_dict['requestParameters']['sourceIPAddress'])
print(s3_dict['bucket']['name'])
print(s3_dict['object']['key'])

receipt_handle = message['ReceiptHandle']

# delete received message from queue
# print('Sleeping for 30 sec before deleting message from queue ...')
time.sleep(5)
sqs.delete_message(QueueUrl=queue_url, ReceiptHandle=receipt_handle)

# add a custom message to queue
# https://boto3.readthedocs.io/en/latest/guide/sqs-example-sending-receiving-msgs.html
response = sqs.send_message(
    QueueUrl=queue_url,
    DelaySeconds=0,
    MessageAttributes={
        'udp_str': {
            'DataType': 'String',
            'StringValue': 'sample string'
        },
        'udp_num': {
            'DataType': 'Number',
            'StringValue': '2018'
        }
    },
    MessageBody=(f'File name = {file_name}')
)




#
# for counter, message in enumerate(queue.receive_messages()):
# 	if counter > 5:
# 		break
#
# 	json_object = json.loads(message)
# 	event_dict = json_object['Records'][0]
# 	s3_dict = event_dict['s3']
#
# 	print(event_dict['eventTime'])
# 	print(event_dict['requestParameters']['sourceIPAddress'])
# 	print(s3_dict['bucket']['name'])
# 	print(s3_dict['object']['key'])
# 	print()
#
# 	# remove message from queue after message successfully processed
# 	message.delete()

# user info
# https://gist.github.com/gene1wood/6d4974b7503336d642c9#file-get_account_id_for_user_ec2instance_role_or_lambda-py
sts = boto3.client(
	'sts',
    aws_access_key_id=aws_public_key,
    aws_secret_access_key=aws_private_key,
	region_name=aws_region_name
)

user_name = sts.get_caller_identity()
print(f'user_name = {user_name}')
print(f'{user_name["Arn"].split("/")[-1]}')

