# test_zip.py

import shutil

# creates extract_dir if doesn't exist
shutil.unpack_archive('landing2/archive.zip', extract_dir='landing3')
