#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Schedule class.

Load a schedule and use .is_ready() to determine if an event should occur.

Schedule definitions
- one time entry per line
- time entries must be HH:MM in 24-hour military format
- illegal time entries are ignored
- time entries are de-duped and sorted
- # comments and blank lines are ignored

schedule.is_ready()
- returns True if current time matches a scheduled time entry
- repeated matches for same time entry within the current day are ignored

"""

import datetime
import re


class Schedule:

	def __init__(self, schedule_definition=None, trace_flag=False):
		self.trace_flag = trace_flag
		self.master_schedule = list()
		self.last_matched_time = '99:99'

		if schedule_definition:
			self.load(schedule_definition)

	def trace(self, message):
		if self.trace_flag:
			print(message)

	# noinspection PyMethodMayBeStatic
	def is_valid_time(self, time_of_day):
		if not re.match('\d\d:\d\d', time_of_day):
			is_valid = False
		else:
			# valid time of day
			hours = int(time_of_day[0:2])
			minutes = int(time_of_day[3:5])
			is_valid = (0 <= hours <= 23) and (0 <= minutes <= 59)
		return is_valid

	def load(self, schedule_definition):
		for line in schedule_definition.splitlines():
			line = line.strip()

			# skip blank lines and comments
			if not line or line.startswith('#'):
				continue

			# take first item on line as time_of_day
			time_of_day = line.split()[0]

			# validate HH:MM time entries
			if self.is_valid_time(time_of_day):
				self.master_schedule.append(time_of_day)
			else:
				self.trace(f'Bad time entry ignored: {time_of_day}')

		# remove dupe time entries, then sort master schedule
		self.master_schedule = list(set(self.master_schedule))
		self.master_schedule.sort()

		# diagnostics
		self.trace(f'Schedule: {self.master_schedule}')

	def is_ready(self, current_time=None):
		if not current_time:
			current_datetime = datetime.datetime.now()
			current_time = current_datetime.strftime('%H:%M')

		# only trigger one scheduled approval per time entry
		if current_time == self.last_matched_time:
			is_ready = False
		else:
			is_ready = current_time in self.master_schedule
			if is_ready:
				self.last_matched_time = current_time

		self.trace(f'Schedule for {current_time}: {is_ready}')
		return is_ready


def test():
	# test schedule
	schedule_definition = '''
	# sample schedule
	
	02:00
	02:30
	03:00
	12:00
	12:15
	12:30
	12:45
	13:00
	
	01:00  # comments can also appear to the right of time entries 
	
	_1:30  # bad time entries get dropped
	99:99  # bad time entries get dropped 
	AB:CD  # bad time entries get dropped
	
	# time entries get sorted so sequence is unimportant  
	01:00
	01:30
	
	# duplicate time entries get de-duped
	02:00
	02:00
	02:00
	'''

	schedule = Schedule(schedule_definition, trace_flag=True)

	# test with test times
	schedule.is_ready('00:15')
	schedule.is_ready('02:00')
	schedule.is_ready('02:00')
	schedule.is_ready('02:00')
	schedule.is_ready('02:00')
	schedule.is_ready('05:00')
	schedule.is_ready('13:00')
	schedule.is_ready('13:30')


# test code
if __name__ == '__main__':
	test()
