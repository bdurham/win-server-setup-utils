# test_extended_dict.py

import codecs
import collections
import json
import pickle
import sys

import hashlib



"""


"""


def is_callable(obj, attr):
	"""
	Returns True if obj.attr exists and is callable (obj.method or module.function).
	Note: Python 3.2+'s callable() only works with objects which have a __call___ method.

	# doctests
	>>> my_dict = dict(a=1, b=2, c=3)
	>>> is_callable(my_dict, 'a')
	False
	>>> is_callable(my_dict, 'keys')
	True
	>>> is_callable(my_dict, 'bad attr')
	False
	"""

	# obj must have attr and attr must be callable in order to return True
	return hasattr(obj, attr) and isinstance(getattr(obj, attr), collections.Callable)


class ObjDict(dict):
	"""
	Dict that supports both obj.attr and obj[attr] access.
	Synonym: DictWithKeysAsAttributes

	# demonstrates read/write referencing dict[keys] via obj.attr notation
	>>> my_dict = dict(a=1, b=2, c=3)
	>>> my_dict = ObjDict(my_dict)
	>>> my_dict.a = 10
	>>> my_dict.sum = my_dict.a + my_dict.b + my_dict.c
	>>> my_dict.sum
	15
	>>> my_dict.a == my_dict['a']
	True
	"""

	def __getattr__(self, name):
		"""Redirect obj.attr to obj[attr]."""
		if name in self:
			return self[name]
		else:
			# raise AttributeError(f'Non-existent attribute: {name}')
			pass


	def __setattr__(self, name, value):
		"""Redirect obj.attr=value to obj[attr]=value."""

		# protect obj's dict methods from being overwritten
		if is_callable(self, name):
			# raise AttributeError(f'Attempt to override existing method: {name}')
			pass
		else:
			self[name] = value

	def __delattr__(self, name):
		"""Safely delete obj.attr; no complaints if attr doesn't exist; obj[ bad_key ] will still raise key error."""
		if name in self:
			del self[name]
		else:
			# raise AttributeError(f'Attempt to delete non-existent attribute: {name}')
			pass


class Column:

	def __init__(self, column_name, data_type='', max_length=0, precision=0, scale=0, encoding=None):
		self.column = ObjDict(dict())
		self.column.column_name = column_name
		self.column.data_type = data_type
		self.column.max_length = max_length


class Column2:

	def __init__(self, column_name, data_type='', max_length=0, precision=0, scale=0, encoding=None):
		self.column_name = column_name
		self.data_type = data_type
		self.max_length = max_length

	def __str__(self):
		return f'{self.column_name}, {self.data_type}, {self.max_length}'


class Schema:

	def __init__(self, table_name):
		self.table_name = table_name
		self.columns = ObjDict(dict())

	def add_column(self, column):
		setattr(self.columns, column.column.column_name, column)


class Schema2:

	def __init__(self, table_name):
		self.table_name = table_name
		self.columns = dict()

	def add_column(self, column):
		self.columns[column.column_name] = column


#
def hash(data):
	# returns a 32 byte array
	salt = b'udp'
	return hashlib.sha256(data + salt).digest()


def is_hashed(data):
	data_bytes = data[0:-32]
	hash_bytes = data[-32:]
	return hash(data_bytes) == hash_bytes



# test code
def main():

	my_dict = dict(a=1, b=2, c=3)
	my_dict = ObjDict(my_dict)

	my_dict.a = 10
	my_dict.b = 20
	my_dict.c = 30
	my_dict.d = 40

	print(my_dict)

	my_dict['a'] = 100
	my_dict['b'] = 200
	my_dict['c'] = 300
	my_dict['d'] = 400
	my_dict['e'] = 500

	print(my_dict)

	# dict keys are NOT exposed as object properties
	print(dir(my_dict))

	# dict keys() returns just dict keys added via dict[key] or dict.key
	print(my_dict.keys())

	# test complex structures
	id_column = Column('id', 'bigint')
	name_column = Column('name', 'char', 16)
	age_column = Column('age', 'int')

	schema = Schema('person')
	schema.add_column(id_column)
	schema.add_column(name_column)
	schema.add_column(age_column)

	print(schema.columns.keys())
	print(schema.columns.name)

	print(schema.columns.name.column)
	json.dumps(schema.columns.name.column)

	name_column = Column2('name', 'char', 16)
	frozen = pickle.dumps(name_column)
	thawed = pickle.loads(frozen)
	print(name_column)
	print(thawed)

	schema = Schema2('person')
	id_column = Column2('id', 'bigint')
	name_column = Column2('name', 'char', 16)
	age_column = Column2('age', 'int')
	schema.add_column(id_column)
	schema.add_column(name_column)
	schema.add_column(age_column)

	frozen = pickle.dumps(schema)
	frozen = frozen + hash(frozen)
	print(f'is_hashed(frozen) = {is_hashed(frozen)}')

	thawed = pickle.loads(frozen)
	for column in thawed.columns:
		print(column)


	sys.exit()

	frozen = pickle.dumps(schema)

	print('Frozen/Thawed Schema/Column object')
	print(thawed.columns.name.column)
	json.dumps(thawed.columns.name.column)


# test code
if __name__ == '__main__':
	main()


