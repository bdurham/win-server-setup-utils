# capture.py (step 1)

# Idea: dev, uat, prod databases in same database, different schemas
# For: reference data, staging, prod databases?
# No: need flexibility to change database engine, etc?

# SQS approach
# - decouples capture, catalog, collect, complete events
# - allows re-running from any particular step by reloading SQS queue with S3 file keys
# - "refill a step's/layer's SQS to re-run"
# - allows earlier steps to continue running independently of later steps
# - IOW, failures/changes at conform/complete stages don't impact capture, catalog, collect phases
#   which continue to run; when later phases fixed/complete they pull from SQS queues to oad data
# - isn't dependent on 5 min Lambda runtimes
# - can scale horizontally by having multiple jobs pull from SQS queues in parallel
# - ports across clouds - replace S3/SQS with target cloud equivalent; core logic remains identical


'''
Strategy
- pull AMP first, then OM; inner join on AMP/OM, then union OM direct
- pull child tables first, parent tables last, parent tables inner join on child (or vice versa ???)
- pull order should guarantee complete sets of data via inner joins ???
- source specific instances for AMP, OM, reference, common_stage, resort-specifc

Transform must reprocess entire season of staged history of AMP/OM because
- transactions may be split across capture pulls
- not all related tables may have been updated
- we associate/de-associate people-product-addons within a full season

Run modes
- as Windows Service, triggered by start times
- command line for non-scheduled run (dev, testing, quick-fix run)

Config
- database connection
- source_id
- start times (list of specific start times)
- s3 bucket base name - source_id added as a prefix (or generic capture bucket with source_id as folder?)
- aws public key
- aws private key

List of start times allows
- skipping blocks of time around overnight cycle
- shifting to more frequent captures over time, 30 min > 5 min

Note: All capture tables/views must have a pk and a sequence or timestamp column
Note: Use a view that joins tables to provide missing pk, sequence or timestamp

Table_Def
- table_name (could be view if joined or column subset)
- pk_column
- sequence_column
- timestamp_column

Job_Log table
- job_id
- source_id
- table_name
- start_time
- end_time
- duration
- max_sequence
- max_timestamp
- rec_count

Naming conventions
- old/new vs previous/current

Setup
- configure database connection, source_id, start times
- configure table_def with table names and sequence or timestamp column names
- add first set of job_id/table_name records with initial max_* values

Restarts
- add a set of job_id records that have initial max_sequence, max_timestamp values
- lower starting values will pull (re-pull) from history

Client side monitoring
- capture.busy - created when capture running, deleted when capture complete

Cloud side monitoring
- watch for gaps in batch*.zip file arrivals
- watch for gaps in batch*-<job_id>*.zip <job_id>'s

Application control files
Note: These will not interupt a capture cycle in progress.
- capture.pause - pauses app capture runs until this file deleted
- capture.restart - "restarts" app, reloads all settings
- capture.exit - forces app to exit


'''

# outer loop reads start times and starts capture cycle
# if a capture cycle takes multiple hours (first run, restart)
# then some capture cycles might be skipped

# before incrementing job_id, creates capture.busy file for external monitoring
# when complete and waiting on next capture run, deletes capture.busy file

# file based commands
# capture.pause - if present, skips updates until deleted
# capture.restart - reloads configuration options without requiring reboot
#
# use capture.pause to pause updates while editing config
#


# try:
	# read config - config file, env, command line

	# increment job id

	# loop through source definitions

	# if not debug: clean output folder (delete temp *.csv files, capture*.zip file)

	# get most recent sequence, timestamps used for source_table's data pull
	# select top 1 max_sequence as old_max_sequence, max_timestamp as old_max_timestamp
	#   where source_table = <source_table>
	#   order by job_id

	# new_max_sequence  = select max( <sequence_column> )
	# new_max_timestamp = select max( <timestamp_column> )

	# select <source_id> as source_id, <job_id> as job_id, *
	# where <sequence_column> between old_max_sequence and new_max_sequence
	# where <timestamp_column> between between old_max_timestamp and new_max_timestamp

	# save as csv

	# log start, stop, duration, record count, max sequence, max update time

	# zip all csv's with capture-<source_id>-<job_id>-<yyyy-mm-dd-hh-mm>,
	# include: current job_log's row of metadata for cloud catalog
	# include: table_def file that allows collect/capture to upsert/merge to stage tables
	# include: latest log trailing of error logs/diagnostics

	# send capture*.zip file to S3 <source_id> bucket or bucket folder


# if successful: update max_sequence, max_update_time for all tables, clear error_log

# if failed: append error log with error diagnostics
# if we have multiple successive failures, our error log will capture each

# if not debug: clean output folder (delete temp *.csv files and batch*.zip file)

###

# TODO: Add try/except/finally wrappers
# TODO: Break out loop bodies to standalone functions

import sys
import pathlib

# globals
job_id = 0        # job id for current pull
times_of_day = [] # list of times of day to pull data

def load_config():
	# time_of_day
	pass


def cleanup():
	# log exit condition
	# close connection, etc.
	sys.exit(1)


def is_restart():
	is_restart_status = False
	# if capture.stop then cleanup()
	# if capture.restart then return True
	# if capture.pause then wait for capture.pause to disappear, then return True
	return is_restart_status


def clear_staging_folder():
	# delete all files from staging folder; error if files remain
	pass


# return True if its time to pull based on start times defined in config file
def is_time_to_pull():
	if not times_of_day:
		reload_times_of_day()

	# delete top N items in times_of_day list that are < time_of_date
	current_time = None
	is_time_to_pull_status = False
	for time_of_day in times_of_day:
		if current_time > time_of_day:
			is_time_to_pull_status = True
			times_of_day.pop(0)

	return is_time_to_pull_status


# reload times_of_day list after all times of day have been cleared
def reload_times_of_day():
	pass


def pull_table(table):
	# select max( {sequence_name} or max( {timestamp_name} to build {condition}
	# select {source_id} as source_id, {job_id} as job_id, * from {table} where {condition}
	# lowercase column names
	# dict_to_csv
	# log source_id, job_id, table_name, start_time, end_time, duration, record_count, max_sequence, max_timestamp
	record_count = 0
	return record_count


# pull tables - return False if restart conditipon
def pull_tables(tables):
	# increment job_id counter
	global job_id
	job_id += 1

	table_count = 0
	record_count = 0
	batch_start_time = 0
	try:
		clear_staging_folder()
		for table in tables:
			if is_restart():
				is_pull_tables_status = False
				break
			table_count += 1
			record_count = record_count + pull_table(table)

		capture_file_name = 'capture-{source_id}-{job_id}-{time_of_day_period}.zip'

		# zip pulled CSVs with job_log record and failures

		# push capture_file_name to S3 bucket
		# push transfer time to S3 bucket (can't be in initial zip because we don't known until transfer completes)
		# clear failure_log
		is_pull_tables_status = True

	except Exception as exception:
		is_pull_tables_status = False
		error_message = exception
		# append failure details (exception diagnostics, optional table failure name, etc) to failure_log

	batch_end_time = 0
	batch_duration = batch_end_time - batch_start_time
	if not is_pull_tables_status:
		# clear current job records from job_log
		# delete from job_log where job_id = job_id
		# add job_id, batch_start_time, batch_end_time, batch_duration, table_count, record_count, error_message to error_log
		pass

	return is_pull_tables_status


# main loop
while True:
	load_config()
	tables = ''

	# (re)open connection

	while True:
		# check for pull time
		if is_time_to_pull():
			if not pull_tables(tables):
				break





