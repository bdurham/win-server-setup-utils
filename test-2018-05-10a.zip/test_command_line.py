# test_command_line.py

import sys

def option(option_name):
	# return option_name in sys.argv
	for item in sys.argv:
		key, separator, value = item.partition('=')
		if key == option_name:
			return True
	return False


def option_value(option_name, default=''):
	for item in sys.argv:
		key, separator, value = item.partition('=')
		if key == option_name:
			return value
	return default

# test code
def main():
	if option('--test'):
		print('Test mode')
	if option('--trace'):
		print('Trace mode')
	if option('--debug'):
		print('Debug mode')
	if option('--log'):
		log_value = option_value('--log')
		print(f'Log value = {log_value}')

# test code
if __name__ == '__main__':
	main()
