# udp_start.py

import ctypes
import datetime
import locale
import os
import platform
import shutil
import socket
import sys

# verify common imports work as expected
# import test_lib


'''
Duplicates:
{os.getenv("COMPUTERNAME", "Unknown")}
{os.getenv("USERNAME", "Unknown")}

'''

class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]

    def __init__(self):
        # have to initialize this to the size of MEMORYSTATUSEX
        self.dwLength = ctypes.sizeof(self)
        super(MEMORYSTATUSEX, self).__init__()

stat = MEMORYSTATUSEX()
ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))


print(f'commandline:   {sys.argv[1:]}')
print(f'current path:  {os.getcwd()}')
print(f'parent folder: {os.path.split(os.getcwd())[-1]}')
print(f'script path:   {sys.argv[0]}')
print(f'python exe:    {sys.executable}')
print(f'python ver:    {sys.version}')
print(f'ptyhon libs:   {sys.path[0]}')
print(f'frozen:        {getattr(sys, "frozen", False)} ({getattr(sys, "c", "")})')
print(f'os version:    {platform.system()} {platform.version()}')
print(f'locale:        {locale.getdefaultlocale()}')
print(f'node name:     {platform.node()}')
print(f'host name:     {socket.gethostname()}')
print(f'host ip:       {socket.gethostbyname(socket.gethostname())}')
print(f'user:          {os.getlogin()}')
print(f'local time:    {datetime.datetime.now()}')
print(f'utc time:      {datetime.datetime.utcnow()}')
print(f'process pid:   {os.getpid()}')
print(f'memory total:  {stat.ullTotalPhys}')
print(f'memory avail:  {stat.ullAvailPhys}')
print(f'memory load:   {stat.dwMemoryLoad}%')
print(f'disk free:     {shutil.disk_usage(os.getcwd())[-1]}')

# print(f'\nTesting test_lib.test(): {test_lib.test("Hello World")}')

'''
print(f'Creating big data ...')
data = "big-data" * 1024 * 1024 * 1024
stat = MEMORYSTATUSEX()
ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
print(f'memory total:  {stat.ullTotalPhys}')
print(f'memory avail:  {stat.ullAvailPhys}')
print(f'memory load:   {stat.dwMemoryLoad}%')
'''
