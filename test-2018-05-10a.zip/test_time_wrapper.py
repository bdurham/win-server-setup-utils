# test_time_wrapper.py

"""
Test a wrapper around time methods that
- adjusts returned time for UTC or a specific timezone/current time zone
- starts at a specific datetime and increments <n> seconds on every call with optional <delay>
- use the increment on call wrapper to fast forward time for testing
- must sync off of source or target database server for consistenty
"""

import datetime
import time
import arrow

class TimeWrapper:

	def __init__(self, start_time, increment, delay=0):
		self.start_time = start_time
		self.current_time = start_time - increment
		self.increment = increment
		self.delay = delay

	def __call__(self):
		self.current_time = self.current_time + self.increment
		if self.delay:
			print(f'Delaying for {self.delay} secs ...')
			time.sleep(self.delay)
		return self.current_time


time_wrapper = TimeWrapper(2000, 30, 5)
# print(time_wrapper())
# print(time_wrapper())
# print(time_wrapper())
# print(time_wrapper())

import database

# SQL Server
server = 'udp-powerbi-sandbox.alterramtnco.com'
dbase = 'Sandy'
user = 'udp_powerbi_sandbox_admin'
password = 'PastrySportAnywhere'
db = database.SQLServerConnection(server, dbase, user, password, debug=True)
conn = db.conn

cursor = conn.cursor()
for i in range(0,5):
	cursor.execute('select getutcdate() as udp_current_time_utc, getdate() as udp_current_time_local;')
	row = cursor.fetchone()
	print(row.udp_current_time_utc, row.udp_current_time_local)
	time.sleep(5)
