# stage.sql

[create_target_table]
if object_id(N'udp_data.{schema_name}.{table_name}', N'u') is not Null
begin
  create table {table_name}(
    {indent(table_column_definitions)},
    {udp_column_definitions}
  );
end;


[create_temp_table]
begin
  create table #{table_name}(
    {indent(table_column_definitions)},
    {udp_column_definitions}
  );
end;


[insert_into_temp_table]
insert into #{table_name}
  ({target_column_names}) values ({source_column_values})


[update_temp_table]
update #{table_name} set
  udp_pk = {udp_pk_expression};


-- TODO: Convert to {var} name and add output for stat tracking
[merge_updates]
-- upsert style merging
merge {table_name} as t with (SERIALIZABLE)
  using #{table_name} as s
  -- use pure join condition vs constraints
  on t.udp_pk = s.udp_pk
when matched then
  -- t.col1 = s.col1, t.col2 = s.col2, ...
  update set {target_equals_source}
when not matched by target then
  -- insert (pk, col1, col2, ...) values (s.pk, s.col1, s.col2, ...)
  insert ({target_column_names}) values ({source_column_names})


-- FUTURE: track staging update stats; updates track as insert/delete - update code below to handle
[merge_output_clause]
output
   $ACTION change_type,
   coalesce (inserted.pk, deleted.pk) udp_pk
   into #udp_merge_stats;
