# archive.sql

# TODO: conditionally create udp_data database
[create_udp_data_database]
create database udp_data;

# formerly udp_catalog and upd_data_catalog
[create_udp_admin_schema]
if not exists (select * from sys.schemas where name=N'udp_admin')
begin
  exec(N'create schema udp_admin authorization [dbo]');
end;


[create_udp_nstpk_lookup_table]
if object_id(N'udp_data.udp_admin.udp_nstk_lookup', N'u') is not Null
begin
  create table udp_nstk_lookup(
    nstpk bigint identity(1,1),
    namespace_table nvarchar(256)
  );
end;


[create_udp_job_log_table]
if object_id(N'udp_data.udp_admin.udp_job_log', N'u') is not Null
begin
  create table udp_job_log(
    jobpk bigint identity(1,1),
    nstpk bigint,
    jobid bigint,
    start_time datetime2,
    end_time datetime2,
    table_count int,
    record_count int,
    transfer_size bigint
  );
end;


# future: track schema alter conditions
[create_udp_table_log_table]
if object_id(N'udp_data.udp_admin.udp_nstk_lookup', N'u') is not Null
begin
  create table udp_table_log(
    jobpk bigint,
    nstkpk bigint,
    record_inserts bigint,
    record_updates bignint,
    capture_runtime float,
    stage_runtime float
  );
end;

