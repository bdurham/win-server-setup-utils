# capture-3.py

"""
Capture
"""


import datetime
import glob
import json
import os
import pathlib
import shutil
import time
import sys

import boto3
import psycopg2
# import pyodbc


# capture frequency in seconds; set to 3600 for hourly captures
capture_frequency = 5
sdlc_env = 'sandbox'


def json_encoder(value):
	"""Encodes date/datetime values as database compatible date/datetime strings."""

	if isinstance(value, datetime.date):
		return value.__str__()
	if isinstance(value, datetime.datetime):
		return value.__str__()


def json_decoder(o):
	"""Not required: Target database accepts strings and converts to date, datetime."""
	pass


def json_test():
	"""Confirm JSON type fidelity."""
	input_file_name = './capture/table1.json'
	with open(input_file_name) as input_stream:
		data_exchange = json.load(input_stream)
		print(f'Table: {data_exchange["table"]}')
		print(f'Cols: {data_exchange["cols"]}')
		print(data_exchange)


class Config:

	def __init__(self):
		self.s3_user = 'udp-admin'
		self.s3_pass = ''
		self.s3_public_key = 'AKIAJYD3U7KONQXEGIVQ'
		self.s3_private_key = 'zQKB7xyKCWFDrkajgVpI2CtIzCFnEp/TbtOkhYoq'


# cname:  udp-powerbi-sandbox.alterramtnco.com
# schema: udp_admin (for data catalog ???)
# schema: udp_amc_amp01_sales
# schema: udp_amc_rtp01_sales
def setup_rds_sandbox():
	"""RDS sandbox via SQL Server"""
	config = Config()
	config.resort = 'sys'
	config.system = 'stage'
	config.subject = 'sales'
	config.db_server = 'udp-powerbi-sandbox.c4yiy3ssz15k.us-west-2.rds.amazonaws.com'
	config.db_port = 1433
	config.db_database = 'udp_staging'
	config.db_user = 'udp_powerbi_sandbox_admin'
	config.db_pass = 'PastrySportAnywhere'
	return config


def setup_amp_uat():
	"""AMP UAT via PostgreSQL"""
	config = Config()
	config.resort = 'amc'
	config.system = 'amp01'
	config.subject = 'sales'
	config.db_server = 'ec2-35-169-118-17.compute-1.amazonaws.com'
	config.db_port = 5432
	config.db_database = 'd560e5pi2h4prd'
	config.db_user = 'ITW'
	config.db_pass = 'p2491b9618451541cf49e0f995dc9c83e33197ed4bf2e3a5bf9cffc83fe9fd7ce'
	return config


def setup_rtp_uat():
	"""RTP UAT via SQL Server"""
	config = Config()
	config.resort = 'amc'
	config.system = 'rtp01'
	config.subject = 'sales'
	config.db_server = 'vm-ded-sqlc1n1.ilab.tst\dev'
	config.db_port = 49733
	config.db_database = 'rtpikon'
	config.db_user = ''
	config.db_pass = ''
	return config


def setup_amp_prod():
	"""AMP PROD via PostgreSQL"""
	config = Config()
	config.resort = 'amc'
	config.system = 'amp01'
	config.subject = 'sales'
	config.db_server = 'ec2-34-237-251-222.compute-1.amazonaws.com'
	config.db_port = 5432
	config.db_database = 'db6oacl4dfhph7'
	config.db_user = 'alterra-data-lake'
	config.db_pass = 'p987e2b5f61d113247839010c38d6dea1287605205f47f7979a3057459bc4ea23'
	return config


def setup_rtp_prod():
	"""RTP PROD via SQL Server"""
	config = Config()
	config.resort = 'amc'
	config.system = 'rtp01'
	config.subject = 'sales'
	config.db_server = 'vn-den-ikonl.idirectory.itw'
	config.db_port = 49733
	config.db_database = 'rtpone'
	config.db_user = ''
	config.db_pass = ''
	return config


def time_to_pull(time_of_last_capture):
	print(f'time_to_pull: {time_of_last_capture + capture_frequency} :: {int(time.time())}')
	ready_to_pull = time_of_last_capture + capture_frequency < int(time.time())
	print(f'Ready to pull: {ready_to_pull}')
	return ready_to_pull


def clear_capture_folder():
	for file_name in glob.glob('./capture/*'):
		print(f'Deleting: {file_name}')
		os.remove(file_name)


def pull_table(conn, table_name):
	output_file_name = f'capture/{table_name}.json'
	print(f'Processing table: {table_name}')

	# sample data
	date_value = datetime.date.today()
	datetime_value = datetime.datetime.now()
	cols = ['str_col', 'int_col', 'float_col', 'bool_col', 'date_col', 'datetime_col', 'null_col']
	row1 = ['Aaa', 100, 111.111, True, date_value, datetime_value, None]
	row2 = ['Bbb', 200, 222.222, True, date_value, datetime_value, None]
	row3 = ['Ccc', 300, 333.333, False, date_value, datetime_value, None]
	rows = [row1, row2, row3]

	# pull list of rows
	data_exchange = dict()
	data_exchange['table'] = table_name
	data_exchange['cols'] = cols
	data_exchange['rows'] = rows

	# On Windows the encoding='utf-8' argument to open is required
	# indent=4: use N spaces to indent each JSON level; otherwise content output as a single line
	# sort_keys=True: sorts dict keys; useful if you want to diff/version json files
	# separators=(',', ': '): prevent trailing whitespaces

	with open(output_file_name, mode='w', encoding='utf-8') as output_stream:
		json.dump(data_exchange, output_stream, indent=4, sort_keys=True, ensure_ascii=False, default=json_encoder)


def zip_tables(name_space, job_id):
	base_name = f'capture/{name_space}-{job_id}'
	root_dir = './capture'
	zip_file_name = shutil.make_archive(base_name, format='zip', root_dir=root_dir)
	print(f'zip file: {zip_file_name}')
	return zip_file_name


def send_to_s3(config, capture_file_name):
	# create the client
	s3_client = boto3.client('s3', aws_access_key_id=config.s3_public_key, aws_secret_access_key=config.s3_private_key, region='us-west-2')

	s3_bucket_name = f'udp-{config.resort}-{sdlc_env}'
	s3_file_name = f'udp-{config.resort}-{config.system}/{capture_file_name}'

	# .upload_file() is a managed uploader that splits files and uploads in parallel
	s3_client.upload_file(capture_file_name, s3_bucket_name, s3_file_name)


def get_job_info():
	input_file_name = 'capture.info'
	if not os.path.exists(input_file_name):
		job_id = 0
		time_of_last_capture = 0
	else:
		with open(input_file_name) as input_stream:
			job_id = int(input_stream.readline())
			time_of_last_capture = int(input_stream.readline())

	return job_id, time_of_last_capture



def put_job_info(job_id, time_of_last_capture):
	output_file_name = 'capture.info'
	with open(output_file_name, mode='w') as output_stream:
		output_stream.write(f'{job_id}\n')
		output_stream.write(f'{time_of_last_capture}\n')


def delete_custom_time_of_last_capture():
	"""Future: Support table specific time_of_last_capture values for onboarding new tables."""
	pass



def main(*args):
	args = None

	# conn = db.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=.;Trusted_Connection=yes;DATABASE=DBTest')
	# conn = pyodbc.connect('DRIVER={SQL Server};SERVER=udp-powerbi-sandbox.c4yiy3ssz15k.us-west-2.rds.amazonaws.com;Trusted_Connection=yes;UID=udp_powerbi_sandbox_admin;PWD=PastrySportAnywhere')
	# cursor = conn.cursor()

	# host, port, dbname, user, password
	config = setup_amp_uat()
	dsn = f'host={config.db_server} port={config.db_port} dbname={config.db_database} user={config.db_user} password={config.db_pass}'
	print(f'Connecting to: {dsn}')
	conn = psycopg2.connect(dsn)
	cursor = conn.cursor()
	cursor.execute('select * from credit_cards')
	for counter, row in enumerate(cursor.fetchall()):
		print(row)
		if counter > 10:
			break

	name_space = f'{config.resort}-{config.system}-{config.subject}'
	job_id, time_of_last_capture = get_job_info()

	while True:
		try:
			if not time_to_pull(time_of_last_capture):
				# sleep between time checks
				time.sleep(1)

			else:
				# pull a new set of incremental updates
				print('Pulling new updates ...')
				job_id = job_id + 1
				time_of_current_capture = int(time.time())
				tables = sorted(glob.glob('*.table'))

				# clear capture folder
				clear_capture_folder()

				# capture tables sequentially
				for table in tables:
					table_name = pathlib.Path(table).stem
					pull_table(conn, table_name)

				zip_tables(name_space, job_id)
				send_to_s3(name_space, config.s3_public_key, config.s3_private_key)

				# only update job info on successful pull and send
				put_job_info(job_id, time_of_current_capture)

				# future - allows onboarding new tables with custom time_of_last_capture
				# Note: stop or pause daemon before updating custom time_of_last_capture times
				delete_custom_time_of_last_capture()

				break

		except Exception as e:
			print(e)
			break

	# cleanup
	cursor.close()
	conn.close()


if __name__ == '__main__':
	main(*sys.argv[1:])
	print('Done')


