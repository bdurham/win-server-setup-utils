# test_postgresql_datetime.py

import datetime
import json
import os
import sys

import arrow
import config
import database

class Track:

	def __init__(self, name):
		self.name = name
		self.start_time = datetime.datetime.now()
		self.stop_time = None
		self.run_time = 0
		print(f'{name} starting ...')

	def stop(self, message=''):
		self.stop_time = datetime.datetime.now()
		self.run_time = (self.stop_time - self.start_time).total_seconds()
		print(f'{self.name} complete in {self.run_time:.1f} secs; {message}')


def json_to_bcp(file_name):
	input_stream = open(f'{file_name}.json')

	json_data = json.load(input_stream)
	output_rows = list()
	for row in json_data:
		pass

	output_stream = open(f'{file_name}.out')
	output_stream.write('\n'.join(output_rows))


def str_to_datetime(datetime_str):
	# ISO 8601 (and %f) only supports 6 vs 7 digits of microsecond precision
	if not datetime_str:
		return datetime_str

	datetime_str = datetime_str.replace('T', ' ')
	if len(datetime_str) == 10:
		# YYYY-MM-DD
		return datetime.datetime.strptime(datetime_str, "%Y-%m-%d")
	elif len(datetime_str) < 20:
		# YYYY-MM-DD HH:MM:SS
		return datetime.datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
	else:
		# YYYY-MM-DD HH:MM:SS.NNNNNN
		return datetime.datetime.strptime(datetime_str[0:26], "%Y-%m-%d %H:%M:%S.%f")


def rows_to_text(file_name, rows):
	delimiter = '\t'
	lines = list()
	for row in rows:
		line = f'{row[0]}{delimiter}{row[1]}{delimiter}{row[2]}'
		lines.append(line)

	with open(file_name, 'w') as output_stream:
		output_stream.write('\n'.join(lines))


# test size and performance to dump large json data sets to text vs insert via DBI API
def json_to_text_files():

	print()
	file_size = os.path.getsize('landing/affiliations.json')
	track = Track(f'Load affiliations.json ({file_size:,})')
	input_stream = open('landing/affiliations.json')
	json_data = json.load(input_stream)
	track.stop(f'rows={len(json_data):,}')

	track = Track('Process rows')
	rows_1 = [(row[0], 'created_at', str_to_datetime(row[14])) for row in json_data]
	rows_2 = [(row[0], 'updated_at', str_to_datetime(row[15])) for row in json_data]
	track.stop()

	track = Track('Combine rows 1-2')
	rows_1.extend(rows_2)
	track.stop(f'rows={len(rows_1):,}')

	track = Track('Save rows to text file')
	rows_to_text('landing/affiliations.txt', rows_1)
	track.stop(f'rows={len(rows_1):,}')

	###

	print()
	file_size = os.path.getsize('landing/order_items.json')
	track = Track(f'Load order_items.json ({file_size:,})')
	input_stream = open('landing/order_items.json')
	json_data = json.load(input_stream)
	track.stop(f'rows={len(json_data):,}')

	track = Track('Process rows')
	rows_1 = [(row[0], 'access_start_date', str_to_datetime(row[10])) for row in json_data]
	rows_2 = [(row[0], 'created_at', str_to_datetime(row[13])) for row in json_data]
	rows_3 = [(row[0], 'updated_at', str_to_datetime(row[14])) for row in json_data]
	track.stop()

	track = Track('Combine rows 1-3')
	rows_1.extend(rows_2)
	rows_1.extend(rows_3)
	track.stop(f'rows={len(rows_1):,}')

	track = Track('Save rows to text file')
	rows_to_text('landing/order_items.txt', rows_1)
	track.stop(f'rows={len(rows_1):,}')

	###

	print()
	file_size = os.path.getsize('landing/order_participants.json')
	track = Track(f'Load order_participants.json ({file_size:,})')
	input_stream = open('landing/order_participants.json')
	json_data = json.load(input_stream)
	track.stop(f'rows={len(json_data):,}')

	track = Track('Process rows')
	rows_1 = [(row[0], 'dob', str_to_datetime(row[5])) for row in json_data]
	rows_2 = [(row[0], 'photo_update_date', str_to_datetime(row[7])) for row in json_data]
	rows_3 = [(row[0], 'waiver_signed_date', str_to_datetime(row[13])) for row in json_data]
	rows_4 = [(row[0], 'created_at', str_to_datetime(row[14])) for row in json_data]
	rows_5 = [(row[0], 'updated_at', str_to_datetime(row[15])) for row in json_data]
	track.stop()

	track = Track('Combine rows 1-5')
	rows_1.extend(rows_2)
	rows_1.extend(rows_3)
	rows_1.extend(rows_4)
	rows_1.extend(rows_5)
	track.stop(f'rows={len(rows_1):,}')

	track = Track('Save rows to text file')
	rows_to_text('landing/order_participants.txt', rows_1)
	track.stop(f'rows={len(rows_1):,}')

# testing to see where the processing bottlenecks are
json_to_text_files()
sys.exit()


"""
date/datetime overflows
- affiliations
- order_items
- order_participants

string values too large; length 65920 buffer 2048
- product_catalogs
- profiles
- ticket_notification_profiles
"""

start_time = datetime.datetime.now()

connect_config = config.Config('config/udp.connect', config.ConnectionSection)
# connect_config.dump()
sql_server_connect = connect_config.sections['database_udp_aws_stage_01_datalake_dev']

db = database.SQLServerConnection(sql_server_connect, debug=True)
conn = db.conn
conn.autocommit = True
conn.setencoding('utf-8') # ODBC v17 requirement ?
cursor = conn.cursor()
cursor.fast_executemany = True

cursor.execute('use test;')
cursor.execute('drop table if exists test;')
cursor.execute('create table test (id int, column_name nvarchar(64), datetime_value datetime2);')

cursor.execute('insert into test values (?, ?, ?)', 1, 'test', datetime.datetime.now())
cursor.execute('select * from test order by id;')
rows = cursor.fetchall()
for row in rows:
	print(row.id, row.column_name, row.datetime_value)
conn.commit()

###

print('Loading affiliations ...')
input_stream = open('landing/affiliations.json')
json_data = json.load(input_stream)

# for row in json_data:
# 	cursor.execute('insert into test values (?, ?, ?)', row[0], 'created_at', arrow.get(row[14]).datetime)
# 	cursor.execute('insert into test values (?, ?, ?)', row[0], 'updated_at', arrow.get(row[14]).datetime)

rows_1 = [(row[0], 'created_at', str_to_datetime(row[14])) for row in json_data]
rows_2 = [(row[0], 'updated_at', str_to_datetime(row[15])) for row in json_data]
sql = '''insert into test (id, column_name, datetime_value) values (?, ?, ?);'''
cursor.executemany(sql, rows_1 + rows_2)

###

print('Loading order_items ...')
input_stream = open('landing/order_items.json')
json_data = json.load(input_stream)

rows_1 = [(row[0], 'access_start_date', str_to_datetime(row[10])) for row in json_data]
rows_2 = [(row[0], 'created_at', str_to_datetime(row[13])) for row in json_data]
rows_3 = [(row[0], 'updated_at', str_to_datetime(row[14])) for row in json_data]

sql = '''insert into test (id, column_name, datetime_value) values (?, ?, ?);'''
cursor.executemany(sql, rows_1 + rows_2 + rows_3)

###

print('Loading order_participants...')
input_stream = open('landing/order_participants.json')
json_data = json.load(input_stream)

rows_1 = [(row[0], 'dob', arrow.get(row[5]).datetime) for row in json_data]
rows_2 = [(row[0], 'photo_update_date', str_to_datetime(row[7])) for row in json_data]
rows_3 = [(row[0], 'waiver_signed_date', str_to_datetime(row[13])) for row in json_data]
rows_4 = [(row[0], 'created_at', str_to_datetime(row[14])) for row in json_data]
rows_5 = [(row[0], 'updated_at', str_to_datetime(row[15])) for row in json_data]

sql = '''insert into test (id, column_name, datetime_value) values (?, ?, ?);'''
cursor.executemany(sql, rows_1 + rows_2 + rows_3 + rows_4 + rows_5)

###

conn.commit()
run_time = datetime.datetime.now() - start_time
print(f'Runtime: {run_time.total_seconds()} secs')
