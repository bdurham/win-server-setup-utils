#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Database connection wrapper.

OPEN: Read property objects to load server, database, etc properties.
OPEN: Only expose a high level cursor, fetchone|many|all, executemany() ???
OPEN: Make cursor and version code more generic.
OPEN: Wrap cursor.execute() to use a generic parameter syntax and optionally log generated SQL and execution times.

"""

# database.py

# standard libs
import pickle
import sys


# database specific libs
import psycopg2
import psycopg2.extensions
import psycopg2.extras
import pyodbc

# udp specific libs
import config


def expand(expression):
	# noinspection PyProtectedMember
	caller_locals = sys._getframe(1).f_locals
	triple_quote = "'" * 3
	return eval(f'f{triple_quote}{expression}{triple_quote}', None, caller_locals)


def quote(items):
	"""Double quote each item in list of items; use for quoting column names that may be reserved words."""
	return [f'"{item}"' for item in items]


class Connection:

	# host, database, username='', password='', port='', debug=False
	def __init__(self, connect_object, debug=False):
		self.engine = connect_object.engine
		self.queryparm = '?'
		self.driver = connect_object.driver
		self.host= connect_object.host
		self.database = connect_object.database
		self.username = connect_object.username
		self.password = connect_object.password
		self.port = connect_object.port
		self.debug = debug

		self.conn = None
		self.connect()
		self.trace(self.version())


	def version(self):
		return 'Version: undefined'

	def trace(self, message):
		if self.debug:
			print(message)

	def connect(self):
		pass


class PostgreSQLConnection(Connection):

	def version(self):
		# DateStyle, TimeZone, integer_datetimes, standard_conforming_strings
		server_encoding = self.conn.get_parameter_status('server_encoding')
		client_encoding = self.conn.get_parameter_status('client_encoding')

		cursor = self.conn.cursor()
		cursor.execute('select version();')
		row = cursor.fetchone()
		if row:
			server_version = row[0]
		else:
			server_version = 'Server version unavailable'

		# conn: encoding, protocol_version, server_version
		version = f'PostgreSQL client adapter: psycopg2 {psycopg2.__version__}; PostgreSQL database server: {server_version}'
		return version

	def connect(self):
		self.engine = 'postgresql'
		self.queryparm = '%s'

		# default PostgreSQL port
		if not self.port:
			self.port = 5432

		# ssl=true
		conn_properties = list()
		conn_properties.append(f'host={self.host}')
		conn_properties.append(f'dbname={self.database}')
		conn_properties.append(f'user={self.username}')
		conn_properties.append(f'password={self.password}')
		conn_properties.append(f'port={self.port}')

		# create the connection
		conn_string = ' '.join(conn_properties)
		self.conn = psycopg2.connect(conn_string)
		self.conn.autocommit = False
		self.conn.cursor_factory = psycopg2.extras.NamedTupleCursor


class SQLServerConnection(Connection):

	def version(self):

		cursor = self.conn.cursor()
		cursor.execute('select @@version;')
		row = cursor.fetchone()
		if row:
			server_version = row[0].splitlines()[0]
		else:
			server_version = 'Server version unavailable'

		version = f'ODBC client adapter: pyodbc {pyodbc.version}, ODBC drivers: {pyodbc.drivers()}; SQL Server database server: {server_version}'
		return version

	def connect(self):
		self.engine = 'sqlserver'
		self.queryparm = '?'
		pyodbc.lowercase = True

		conn_properties = list()

		# if you are running on Windows, you can just use the native driver: driver={SQL Server}
		# Note: Use driver={SQL Server} in non-Windows (Linux/MacOS) environments.
		# Note: Latest driver=ODBC Driver 17 for SQL Server;
		if not self.driver:
			# driver = 'ODBC Driver 13 for SQL Server'
			self.driver = '{SQL Server}'

		# enclose driver name in curly braces if curly braces not present in driver value
		if not self.driver.startswith('{'):
			self.driver = f'{{{self.driver}}}'

		conn_properties.append(f'driver={self.driver}')

		# if port override, must provide as part of host name vs "port=" parameter
		if self.port:
			conn_properties.append(f'server={self.host},{self.port}')
		else:
			conn_properties.append(f'server={self.host}')

		# optional database name to open ("use") on connect
		if self.database:
			conn_properties.append(f'database={self.database}')

		# use trusted_connection -OR- user/password (these are mutually exclusive options)
		if not self.username:
			conn_properties.append('trusted_connection=yes')
		else:
			conn_properties.append(f'uid={self.username}')
			conn_properties.append(f'pwd={self.password}')

		# create the connection
		conn_string = '; '.join(conn_properties)
		print(f'SQLServer(pyodbc): {conn_string}')
		self.conn = pyodbc.connect(conn_string)
		self.conn.autocommit = False


class Column:

	def __init__(self, column):
		self.column_name = column.column_name
		self.data_type = column.data_type
		self.is_nullable = column.is_nullable
		self.character_maximum_length = column.character_maximum_length
		self.numeric_precision = column.numeric_precision
		self.numeric_scale = column.numeric_scale
		self.datetime_precision = column.datetime_precision
		self.character_set_name = column.character_set_name
		self.collation_name = column.collation_name

	def __str__(self):
		return f'Column {self.column_name}: {self.data_type}'


class Table:

	def __init__(self, table_name, columns):
		self.table_name = table_name
		self.columns = dict()
		for column in columns:
			self.columns[column.column_name] = Column(column)

	def column_definitions(self):
		column_definitions = list()
		for column_name, column in self.columns.items():
			null_mode = 'null'
			if column.is_nullable == 'NO':
				null_mode = 'not null'

			details = ''
			if column.character_maximum_length:
				if column.character_maximum_length == -1:
					details = '(max)'
				else:
					details = f'({column.character_maximum_length})'

			if column.data_type == 'datetime2':
				# force highest precision
				details = '(7)'

			# note indentation for visual debugging
			column_definitions.append(f'  "{column.column_name}" {column.data_type}{details} {null_mode}')
		return ',\n'.join(column_definitions)


"""
Python DB API-compliance: auto-commit is off by default. You need to call conn.commit to commit any pending transaction.
Connections (and cursors) are context managers, you can simply use the with statement to automatically commit/rollback a 
transaction on leaving the context.

When a connection exits the with block, if no exception has been raised by the block, the transaction is committed. 
If an exception was raised, then the transaction is rolled back.
When a cursor exits the with block it is closed, releasing any resources associated with it.

# start a transaction and create a cursor
with conn, conn.cursor() as cursor:  
    cursor.execute(sql)
"""

class Database:

	def __init__(self, engine, conn):
		self.engine = engine
		self.queryparm = ''
		if engine == 'postgresql':
			self.queryparm = '%s'
		if engine == 'sqlserver':
			self.queryparm = '?'

		self.conn = conn

		if engine == 'sqlserver':
			# changed from True to False on Tue 2018-05-08
			self.conn.autocommit = False
		self.cursor = self.conn.cursor()
		self.sql_config = config.ConfigSectionValue(f'config/{engine}.sql')

	def log(self, command_name, sql):
		print(f'# {command_name}\n{sql}\n')

	def sql(self, command):
		return self.sql_config.sections[command]

	def is_null(self, sql_command):
		command_name = 'is_null'
		# self.log(command_name, sql_command)

		self.cursor.execute(sql_command)
		row = self.cursor.fetchone()
		if row:
			# print(f'not_null(row[0]) = {row[0]}')
			return row[0] is None
		else:
			# print(f'not_null() - no row')
			return True

	def execute(self, command_name, value=None):
		queryparm = self.queryparm
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		if value is None:
			cursor = self.cursor.execute(sql_command)
		else:
			cursor = self.cursor.execute(sql_command, value)
		self.log(command_name, sql_command)
		return cursor

	def does_database_exist(self, database_name):
		command_name = 'does_database_exist'
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		return not self.is_null(sql_command)

	def create_database(self, database_name):
		command_name = 'create_database'
		if not self.does_database_exist(database_name):
			autocommit = self.conn.autocommit
			self.conn.autocommit = True
			sql_template = self.sql(command_name)
			sql_command = expand(sql_template)
			self.log(command_name, sql_command)
			self.cursor.execute(sql_command)
			self.conn.autocommit = autocommit

	def use_database(self, database_name):
		command_name = 'use_database'
		sql_template = self.sql('use_database')
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		self.cursor.execute(sql_command)

	def does_schema_exist(self, schema_name):
		command_name = 'does_schema_exist'
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		return not self.is_null(sql_command)

	def create_schema(self, schema_name):
		command_name = 'create_schema'
		if not self.does_schema_exist(schema_name):
			autocommit = self.conn.autocommit
			self.conn.autocommit = True
			sql_template = self.sql(command_name)
			sql_command = expand(sql_template)
			self.log(command_name, sql_command)
			self.cursor.execute(sql_command)
			self.conn.autocommit = autocommit

	def does_table_exist(self, schema_name, table_name):
		command_name = 'does_table_exist'
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		return not self.is_null(sql_command)

	def select_table_schema(self, schema_name, table_name):
		command_name = 'select_table_schema'
		if not self.does_table_exist(schema_name, table_name):
			print(f'Table not exist: {schema_name}.{table_name}')
			return None
		else:
			sql_template = self.sql(command_name)
			sql_command = expand(sql_template)
			self.log(command_name, sql_command)
			self.cursor.execute(sql_command)
			return Table(table_name, self.cursor.fetchall())

	def create_table_from_table_schema(self, schema_name, table_name, table):
		command_name = 'create_table_from_table_schema'
		if not self.does_table_exist(schema_name, table_name):
			autocommit = self.conn.autocommit
			self.conn.autocommit = True
			column_definitions = table.column_definitions()
			sql_template = self.sql(command_name)
			sql_command = expand(sql_template)
			self.log(command_name, sql_command)
			self.cursor.execute(sql_command)
			self.conn.autocommit = autocommit

	# TODO: Replace schema_name, table_name with [command_name]
	def create_named_table(self, schema_name, table_name):
		command_name = f'create_named_table_{schema_name}_{table_name}'
		if not self.does_table_exist(schema_name, table_name):
			autocommit = self.conn.autocommit
			self.conn.autocommit = True
			sql_template = self.sql(command_name)
			sql_command = expand(sql_template)
			self.log(command_name, sql_command)
			self.cursor.execute(sql_command)
			self.conn.autocommit = autocommit

	def drop_table(self, schema_name, table_name):
		command_name = 'drop_table'
		if self.does_table_exist(schema_name, table_name):
			autocommit = self.conn.autocommit
			self.conn.autocommit = True
			sql_template = self.sql(command_name)
			sql_command = expand(sql_template)
			self.log(command_name, sql_command)
			self.cursor.execute(sql_command)
			self.conn.autocommit = autocommit

	def insert_into_table(self, schema_name, table_name, **column_names_values):
		command_name = f'insert_into_table'
		column_names = ', '.join(quote(column_names_values.keys()))
		column_placeholders = ', '.join([self.queryparm] * len(column_names_values))
		column_values = column_names_values.values()
		autocommit = self.conn.autocommit
		self.conn.autocommit = True
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		self.cursor.execute(sql_command, *column_values)
		self.conn.autocommit = autocommit

	def bulk_insert_into_table(self, schema_name, table_name, table_schema, rows):
		command_name = f'insert_into_table'
		column_names = ', '.join(quote(table_schema.columns))
		column_placeholders = ', '.join([self.queryparm] * len(table_schema.columns))
		autocommit = self.conn.autocommit
		self.conn.autocommit = False # 2018-05-06
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		self.cursor.fast_executemany = True # 2018-05-06
		row_count = self.cursor.executemany(sql_command, rows)
		self.cursor.commit() # 2018-05-06
		self.conn.autocommit = autocommit
		return row_count

	def capture_select(self, schema_name, table_name, column_names, last_timestamp=None, current_timestamp=None):
		command_name = f'capture_select'
		column_names = ', '.join(quote(column_names))

		autocommit = self.conn.autocommit
		if self.engine == 'sqlserver':
			self.conn.autocommit = True

		sql_template = self.sql(command_name)
		print(f'\ncapture_select.sql_template:\n{sql_template}\n')
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		self.cursor.execute(sql_command)
		if self.engine == 'sqlserver':
			self.conn.autocommit = autocommit
		return self.cursor

	def delete_where(self, schema_name, table_name, value):
		command_name = f'delete_where'


	# TODO:
	# insert into
	# update
	# merge

	'''
	[get_pk]
	[get_pk]
	select {pk_column_name} as pk
	  from {schema_name}.{table_name}
	  where {nk_column_name} = {nk_column_value};

	[insert_pk]
	insert into {schema_name}.{table_name}
	  {column_names}
	  values
	  {column_values};
	'''

	# Future: cache pk requests in a local session dict; pk's will never change once issued
	def get_pk(self, schema_name, table_name, pk_column_name, nk_column_name, **key_values):
		command_name = f'get_pk'

		pk_conditions = list()
		for key, value in key_values.items():
			pk_conditions.append(f'{key}={value}')
		pk_conditions = ' and '.join(pk_conditions)

		autocommit = self.conn.autocommit
		self.conn.autocommit = True
		sql_template = self.sql(command_name)
		sql_command = expand(sql_template)
		self.log(command_name, sql_command)
		self.cursor.execute(sql_command)
		self.conn.autocommit = autocommit


# test code
def main():

	# SQL Server
	connect_config = config.Config('config/udp.connect', config.ConnectionSection)
	connect_config.dump()
	sql_server_connect = connect_config.sections['amc_aws_udp_01_dev']

	db = SQLServerConnection(sql_server_connect, debug=True)
	conn = db.conn
	cursor = conn.cursor()
	cursor.execute('select * from udp_staging.udp_amc_rtp01_sales.closeheader;')
	rows = cursor.fetchall()
	for row in rows:
		print(row.udp_job, row)
	print()

	database = Database('sqlserver', conn)
	database.create_database('test123')
	database.use_database('test123')
	database.create_schema('test_schema')
	database.use_database('udp_staging')

	# test creating udp_admin tables via create_named_table
	database.create_schema('udp_admin')
	table = database.select_table_schema('dbo', 'dimproduct')
	database.create_table_from_table_schema('udp_admin', 'dimproduct2', table)
	database.create_named_table('udp_admin', 'nst_lookup')
	# database.create_named_table('udp_admin', 'job_log')
	# database.create_named_table('udp_admin', 'table_log')

	# 2018-05-02 stopped:
	# extend create tables with custom udp* columns defined as a block
	# capture: udp_jobid, udp_timestamp, udp_rowversion
	# stage:. udp_pk (identity for non-temp), udp_nk (based on primary key), udp_nstpk, udp_jobpk,
	# TODO: extra columns for #target (no identity) are slightly different than target (pk default identity)


	# test staging management of arriving archived capture files
	database.use_database('udp_stage')
	database.create_schema('udp_catalog')

	database.drop_table('udp_catalog', 'stage_arrival_queue')
	database.drop_table('udp_catalog', 'stage_pending_queue')

	database.create_named_table('udp_catalog', 'stage_arrival_queue')
	database.create_named_table('udp_catalog', 'stage_pending_queue')

	new_file = dict(archive_file_name='amc_heroku_amp_01_sales-1.zip', job_id=1)
	database.insert_into_table('udp_catalog', 'stage_arrival_queue', **new_file)
	new_file = dict(archive_file_name='amc_heroku_amp_01_sales-2.zip', job_id=2)
	database.insert_into_table('udp_catalog', 'stage_arrival_queue', **new_file)
	new_file = dict(archive_file_name='amc_heroku_amp_01_sales-3.zip', job_id=3)
	database.insert_into_table('udp_catalog', 'stage_arrival_queue', **new_file)

	# new_file = dict(archive_file_name='amc_heroku_amp_01_sales-1.zip')
	# database.insert_into_table('udp_catalog', 'stage_pending_queue', **new_file)

	# any new arrivals that we can process? job_id=1 or next job in sequence?
	cursor = database.execute('select_from_stage_arrival_queue')
	row = cursor.fetchone()
	if row:
		# get object_key we should fetch for staging
		print(f'Found next file to stage: {row}')
		archive_file_name = row.archive_file_name
		job_id = int(archive_file_name.split('.')[0].rsplit('-', 1)[-1])
		namespace = archive_file_name.rsplit('-', 1)[0]
		object_key = f'{namespace}/{archive_file_name}'

		print(f'fetch from archives: {object_key}\n')

		# remove the file from both the arrival and pending queues
		database.execute('delete_from_stage_arrival_queue', archive_file_name)
		database.execute('delete_from_stage_pending_queue', archive_file_name)

		# post the next file in sequence for namespace to pending queue
		next_archive_file_name = f'{namespace}-{job_id+1}.zip'
		next_file = dict(archive_file_name=next_archive_file_name)
		database.insert_into_table('udp_catalog', 'stage_pending_queue', **next_file)


	# TODO: 2018-05-02
	# [create_named_table_udp_catalog_stage_queue]
	# [insert_into_named_table_udp_catalog_stage_queue]
	# [select_from_named_table_udp_catalog_stage_queue]
	# [update_named_table_udp_catalog_stage_queue_
	# [update_named_table_udp_catalog_stage_queue_new_
	# namespace, job_id, is_last_staged, is_pending, queued_timestamp
	# archive processes capture file: insert namespace, jobid, 0, 1, now() into stage_queue
	# stage poll - select new jobs in sequence
	# update


	# Table.postgresql_to_sqlserver()
	# Table.sqlserver_to_sql_server()

	# PostgreSQL
	postgresql_connect = connect_config.sections['amc_heroku_amp_01_dev']
	db = PostgreSQLConnection(postgresql_connect, debug=True)
	conn = db.conn
	# cursor = conn.cursor()
	# cursor.execute('select * from guests limit 10;')
	# for row in cursor.fetchall():
	# 	print(row.email, row)
	database = Database('postgresql', conn)

	table_name = 'carts'
	table_1 = database.select_table_schema('public', table_name)
	output_stream = open(f'{table_name}.schema', 'wb')
	pickle.dump(table_1, output_stream)
	output_stream.close()

	input_stream = open(f'{table_name}.schema', 'rb')
	table_2 = pickle.load(input_stream)
	input_stream.close()
	for column in table_2.columns:
		print(table_2.columns[column])

	sys.exit()

# test code
if __name__ == '__main__':
	main()
