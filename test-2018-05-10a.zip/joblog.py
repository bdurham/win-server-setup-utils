#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
joblog.py

Captures job specific step metrics.

Measures: what, when, how long, how many, how big, status, why (message?)

Use: capture, archive, stage, ...

Todo:
- how to get first item in a dict: list(d.values())[0]
- how to deserialize json iso date/timestamp string to date/datetime values ???
- save where we save column names and rows to json; make this a generic class with date/datetime serial/deserial logic

import json
import namedtuple from collections

# saving a namedtuple to json saves it as a list
Column = namedtuple('Column', 'name, type, size')
job_id_column = Column('job_id', 'int', 8)
json.dumps(column)

# restoring a namedtuple from json list
job_id_column = Column(*json.loads(json.dumps(job_id_column)))

"""


# standard libs
import datetime
import json
import random
import time


# TODO: json_deserializer() for iso date/datetime saved as strings
# TODO: need to know 'path' to these data elements and their date/datetime types
# TODO: path is dict key, list index
def json_deserialize(data):
	pass


def random_sleep(max_seconds):
	"""Test-Code: Sleep for a random number of seconds; for testing job logs."""
	time.sleep(max_seconds * random.random())


# TODO: When we capture data we need need to extend column names/types w/our added udp* columns: jobid, timestamp, ...
# NOTE: This class is only for capturing values/saving them/restoring them.
# NOTE: Other classes handle the extract from or insert into source/target databases or other data sources.
class JsonTable:

	def __init__(self, column_names, column_types):
		# these are lists of column names and column types
		self.column_names = column_names
		self.column_types = column_types

	def json_serialize(self, obj):
		"""json serializer for date types not serializable by default json code"""
		if isinstance(obj, (datetime.datetime, datetime.date)):
			return obj.isoformat()

	# todo: deserialize date, datetime, and binary stored as base64 ???
	def load(self, file_name):
		pass

	def save(self, file_name, rows):
		output = dict()
		output['column_names'] = self.column_names
		output['column_types'] = self.column_types
		output['rows'] = rows

		# save data in json format
		with open(file_name, 'w') as output_stream:
			json.dump(output, output_stream, indent=2, default=self.json_serialize)


class JobStep:

	def __init__(self, job_id, step_object, step_action):
		self.job_id = job_id
		self.step_object = step_object
		self.step_action = step_action
		self.status = ''
		self.start_time = datetime.datetime(1900, 1, 1)
		self.stop_time = datetime.datetime(1900, 1, 1)
		self.run_time = 0
		self.count = 0
		self.size = 0

	def start(self):
		self.start_time = datetime.datetime.now()

	def stop(self, count=0, size=0):
		self.stop_time = datetime.datetime.now()
		self.run_time = (self.stop_time - self.start_time).total_seconds()
		self.count = count
		self.size = size

	@staticmethod
	def column_names():
		output = list()
		output.append('job_id')
		output.append('step_object')
		output.append('step_action')
		output.append('status')
		output.append('start_time')
		output.append('stop_time')
		output.append('run_time')
		output.append('count')
		output.append('size')
		return output

	@staticmethod
	def column_types():
		"""Create a temp job step and discover its attributes' types"""
		temp_job_step = JobStep(0, '', '')
		output = list()
		for column_name in JobStep.column_names():
			output.append(type(getattr(temp_job_step, column_name)).__name__)
		return output

	def column_types_old(self):
		output = list()
		for column_name in self.column_names():
			output.append(type(getattr(self, column_name)).__name__)
		return output

	def to_list(self):
		output = list()
		for column_name in self.column_names():
			output.append(getattr(self, column_name))
		return output


class JobLog:

	def __init__(self, job_id):
		self.job_id = job_id
		self.job_steps = dict()

	def start(self, step_object, step_action):
		step_name = f'{step_object}:{step_action}'
		self.job_steps[step_name] = JobStep(self.job_id, step_object, step_action)
		self.job_steps[step_name].start()

	def stop(self, step_object, step_action, count=0, size=0):
		step_name = f'{step_object}:{step_action}'
		self.job_steps[step_name].stop(count, size)

	def save_old(self, file_name):
		output = dict()
		output['column_names'] = list()
		output['column_types'] = list()
		output['rows'] = list()

		if self.job_steps:
			output['column_names'] = JobStep.column_names()

			# get column types
			first_step = list(self.job_steps.values())[0]
			output['column_types'] = first_step.column_types()

			# get row data
			for step_name, job_step in self.job_steps.items():
				output['rows'].append(job_step.to_list())

		# save data in json format
		with open(file_name, 'w') as output_stream:
			json.dump(output, output_stream, indent=2)  # , default=json_serialize)

	def save(self, file_name):
		column_names = JobStep.column_names()
		column_types = JobStep.column_types()
		table = JsonTable(column_names, column_types)
		rows = list()
		for job_step in self.job_steps.values():
			rows.append(job_step.to_list())
		table.save(file_name, rows)

	def insert(self):
		"""
		Return list of column names and list of corresponding values

		# column_markers is comma delimited list for DBI specific replaceable column values, eg. %s, {n}, etc
		cursor.execute(f'insert into {table_name} ({column_names}) values ({column_markers})', values)

		"""
		pass


"""
Future: A better way to work with job logs?

Future:
- rename JobLog > Log
- rename step_name > event_name
- rename step_object > event_object
- rename step_action > event_action

job_log = JobLog( jobid )
event = job_log.start( event_name, event_action='' )
event.stop( count=0, size=0 )

# job start
job_log = JobLog(jobid)
job_event = job_log.start( 'job', 'capture' )

<bunch of events>
event = job_log.start( 'table1', 'capture' )
<do stuff>
event.stop( count=0, size=0 )

# job end
job_event.stop()
job_log.save( file_name )


"""


# test code
def main():
	job_id = 123
	job_log = JobLog(job_id)
	job_log.start('job', 'capture')
	random_sleep(1)

	job_log.start('table-1', 'schema')
	random_sleep(1)
	job_log.stop('table-1', 'schema', 100, 1000)

	job_log.start('table-1', 'rowcount')
	random_sleep(1)
	job_log.stop('table-1', 'rowcount', 200, 2000)

	job_log.start('table-1', 'capture')
	random_sleep(1)
	job_log.stop('table-1', 'capture', 300, 3000)

	job_log.start('capture.zip', 'compress')
	random_sleep(1)
	job_log.stop('capture.zip', 'compress', 300, 3000)

	random_sleep(1)
	job_log.stop('job', 'capture')
	job_log.save('stat.test')


# test code
if __name__ == '__main__':
	main()
