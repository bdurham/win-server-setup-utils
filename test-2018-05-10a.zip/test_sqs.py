# test_sqs.py

import boto3
import datetime
import json

aws_region_name = 'us-west-2'
aws_public_key = 'fill-in'
aws_private_key = 'fill-in'

sqs = boto3.client(
	'sqs',
    aws_access_key_id=aws_public_key,
    aws_secret_access_key=aws_private_key,
	region_name=aws_region_name
)

response = sqs.list_queues()
print(response)

queue_name = 'udp-sqs-fill-in-queue-name'
response = sqs.get_queue_url(QueueName=queue_name)
queue_url = response['QueueUrl']
print(f'queue_url = {queue_url}')

response = sqs.receive_message(
  QueueUrl=queue_url,
  MaxNumberOfMessages=1,
  MessageAttributeNames=['All'],
  VisibilityTimeout=0,
  WaitTimeSeconds=0
)

message = response['Messages'][0]
