# test_table_gen.py

"""
Write a utility to take create table scripts from PostgreSQL/SQL Server
and generate skeleton table def files
- remove [dbo].
- remove [, ] (we add to column names when we generate scripts
- lowercase column and type names

Input
- table name
- table prefix - added to table name as prefix when pulling from source (optional)
- table suffix - added to table name as suffix when pulling from source (optional)
- columns - column definitions in terms of target staging
- cdc type - timestamp, rowversion, replace (covers both truncate and reload and drop and rebuild)
- cdc rowversion - expression that's equivalent to SQL Server ROWVERSION ("timestamp")
- cdc timestamp - expression that returns a date/datetime expression for cdc range checks
- cdc select - select (may have joins) to retrieve a specific batch; make as generic as possible vs source specific
- timestamp expression - calculated in target database #temp table
- pk expression - calculated in target database #temp table
- first_time - date of first pull if table hasn't been pulled yet (based on table name in .history file)
- first_rowversion - first rowversion value (integer) used for initial pull

Output
- use between syntax vs >= and <= (see Evernote SQL between research)
- select *, <cjob_id> as udp_jobid where <CDC_expression> to pull changed data
- create table (...) to create missing staging tables wrapped with if table not exist
- create #table
- merge from #table into table where table.udp_nk = #table.udp_nk
- staging - begin trans ... commit/rollback on error template

Create table with auto-incrementing key
<column> int identity(1,1) - note we don't append PRIMARY KEY because our staging has no constraints by intent

udp_pk bigint identity(1,1)

Admin tables
- job - job stats by namespace by capture, archive, stage, unify (job id persists across steps/layers)
- table - job specific table stats
- namespace - assigns surrogate PK's to namespace-table tuples

Upcoming
- change management *.change files

###

Open: SQL Server rowversion (timestamp) columns not supported by columnstore and in-memory tables

But:
- staging tables are heap vs columnstore; rowversion info may be relevant so we can't drop it
- staging tables are disk vs in-memory ???

Workarounds - if necessary
- detect rowversion/timestamp column ty pes, to bigint columns in staging, and cast rowversion to bigint in stage

...

Open: truncate and drop will cause udp_pk and udp_guid values to be lost

Workaround:
- extract udp_pk, udp_gui, udp_nk to a temp table
- determine max udp_pk + 1; this will be starting point for replacement table's udp_pk identity seed
- rebuild table with udp_pk as a NON-identity column
- load replacement records that have udp_nk that matches extracted udp_nk's ...
- ... this preserves existing udp_pk, udp_guid values
- alter table and set udp_pk as an identity column seeded with max upd_pk + 1 value determined earlier
- load replacement records that DON'T have a matching udp_nk value; these will get new auto-incremented udp_pk's
- update all udp_guid codes across new records (or all records)

###

Next: Intrawest: MVP - SQL templates
- generate SQL code from TableDef object


"""


import arrow


config_def = '''
db_source = amc_amp01_sales_sandbox (includes database engine in definition)
db_engine = PosgreSQL

'''


def normalize_line(line):
	"""Convert tabs to spaces, condense runs of 2+ spaces to a single space, trim spaces"""
	line = line.replace('\t', ' ')
	return ' '.join(line.split())


def single_line(line):
	if not line:
		line = ''
	else:
		line = line.splitlines()[0].strip()
	return line


def indent(text, tab_count=1):
	"""Indent each line with tab_count tabs."""

	lines = list()
	for line in text.splitlines():
		line = '\t' * tab_count + line.strip()
		lines.append(line)

	# return indented lines
	return '\n'.join(lines)


def dedent(text):
	"""Strip leading tab indentation from all lines in text."""
	return '\n'.join(line.strip() for line in text.splitlines())


def dedent_min(text):
	"""Figure out min leading tabs and remove that amount of tabs from all lines."""

	# count tabs at the beginning of each line
	tabs = list()
	for line in text.splitlines():
		# ignore blank lines
		if not line.strip():
			continue

		tab_count = 0
		for tab_count, char in enumerate(line):
			if char != '\t':
				break
		tabs.append(tab_count)

	# calculate the min number of tabs present
	min_tabs = min(tabs)
	print(f'tab counts = {tabs}')

	# remove the the min number of tabs from each line
	lines = list()
	for line in text.splitlines():
		line = line.replace('\t' * min_tabs, '', 1)
		lines.append(line)

	# return dedented lines
	return '\n'.join(lines)


# 2018-03-01T00:00
def is_iso_timestamp(timestamp):
	try:
		arrow.get(timestamp, 'YYYY-MM-DDTHH:mm')
		iso_timestamp_status = True
	except ValueError:
		iso_timestamp_status = False

	return iso_timestamp_status


udp_create_table_sql = '''
create table {table_name}(
	{indent(column_definitions)},
	{indent(udp_column_definitions)}
);
'''

udp_column_definition_sql = '''
udp_jobid int not null,
udp_timestamp datetime not null
'''


class TableDef:

	def __init__(self, db_engine):
		self.commands = ('#define ', '#eof')
		self.comment_chars = ('/', '#')

		self.db_engine = db_engine.replace(' ', '').lower()
		self.table_name = ''
		self.table_prefix = ''
		self.table_suffix = ''
		self.columns = ''
		self.nk_expression = ''
		self.cdc_type = ''
		self.row_timestamp = ''
		self.row_version = ''
		self.cdc_select = ''
		self.first_time = ''
		self.first_rowversion = ''

	@staticmethod
	def trace(text):
		print(text)

	def is_comment(self, line):
		comment_status = False

		line = line.lower()
		if line.startswith(self.commands):
			comment_status = False
		elif not line or line.startswith(self.comment_chars):
			comment_status = True

		return comment_status

	def column_names(self):
		"""Returns a list of column names."""
		values = list()
		for line in self.columns.splitlines():
			print(f'line = [{line}]')
			column_name = line.split()[0]
			values.append(column_name)
		return values

	def load(self, file_name):
		with open(file_name) as input_stream:
			lines = input_stream.readlines()

		# force last define to be processed
		lines.append('#eof')

		defines = dict()
		define_name = ''
		define_value = ''
		for line_number, line in enumerate(lines, 1):
			line = normalize_line(line)
			if self.is_comment(line):
				continue

			if not line.lower().startswith(self.commands):
				# add line to current define
				define_value = f'{define_value}\n{line}'
			else:
				# new commands always save current definition
				command = line.partition(' ')[0].lower()
				if define_name:
					# cleanup and validate value before saving
					define_value = define_value.strip()
					if define_name != 'columns':
						# take first line of value for all properties except column definitions
						define_value = single_line(define_value)

					if self.first_time and not is_iso_timestamp(self.first_time):
						self.trace('Bad ISO timestamp for first_time property: {self.first_time}')

					# save previous definition and validated value
					setattr(self, define_name, define_value)

					# for testing only
					defines[define_name] = define_value.strip()

				# start a new define
				define_name = line.partition(' ')[2].lower()
				define_value = ''

				# validate define_name
				if define_name and not hasattr(self, define_name):
					self.trace(f'Unknown property at line {line_number}: {define_name}')
					define_name = ''

				if command == '#eof':
					break

	def dump(self):
		# for key, value in defines.items():
		# 	print(f'{key} = {value}\n')
		pass

	def generate_cdc_select(self, job_id, last_update, current_update, test_mode=False):
		column_names = ', '.join(self.column_names())

		min_timestamp = f'''{self.row_timestamp} >= {last_update}'''
		max_timestamp = f'''{self.row_timestamp} < {current_update}'''
		where_condition = f'''({min_timestamp} and {max_timestamp})'''
		if test_mode:
			where_condition = f'({where_condition}) and (0=1)'

		select_statement = f'''
		select {column_names}, {job_id} as udp_jobid, {self.row_timestamp} as udp_timestamp
			from {self.table_name}
			where {where_condition};
		'''
		return dedent(select_statement)

	def generate_create_table(self):
		create_statement = dedent(udp_create_table_sql)
		table_name = self.table_name
		column_definitions = self.columns
		create_statement = f'''{create_statement}'''
		print(eval(f"""'{create_statement}'"""))
		return create_statement

# test code
def main():
	table_def = TableDef('SQL Server')
	table_def.load('sample.def')
	print(f'Database engine: {table_def.db_engine}')
	print(f'Column names: {table_def.column_names()}')

	timestamp = arrow.now()
	timestamp = timestamp.shift(minutes=-1)
	last_update = timestamp.format(fmt='YYYY-MM-DDTHH:mm')
	current_update = timestamp.shift(hours=+1).format(fmt='YYYY-MM-DDTHH:mm')

	# print(table_def.generate_cdc_select(10, last_update, current_update, test_mode=True))

	# print(table_def.generate_create_table())


# test code
if __name__ == '__main__':
	main()
