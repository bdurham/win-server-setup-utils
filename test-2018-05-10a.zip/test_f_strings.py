# test_f_strings.py

"""

Open:

0. Time, timezone and scheduler wrapper

- db_timezone - utc, or specific hourly offset from gmt/zulu
- our capture utility will run in Denver and pull from utc and mt systems
- our capture utility will run on east/west coasts and pull from utc and est/west-coast time systems
- when returning current time, adjust to db_timezone !!!!
- always skip fall season DST(?) 12:30am-2:30am because there will be TWO 1-2am time blocks and a 25 hour day
- don't have to skip around spring season because we spring ahead an hour and drop 1-2am time block with a 23 hour day
- KEY: current_time, last_time, etc all timezone adjusted to source system !!!!

0. mock datetime.now() to fake hourly returns every N seconds so we can speed up time
- set to Mar 6, then every 60 seconds, advance an hour and re-pull based on new mock date
- we can pull a day in 24 min and a month in 30 * 24 = 720 min in 12 hours

0. when pulling by timestamp ... !!!!
- find table's latest timestamp or use capture server timestamp?
- adjust timestamp(s) to utc or server timezones?
- amc-amp timestamps are utc w/out dst
- amc-rtp timestamps are mt w/dst


###

Naming conventions

0. project config for a specific resort - system - INSTANCE - subject area
- Note: All files in a capture project pull from same database/database engine
- SOLUTION: Use database_engine, database_port, etc vs db_*
- database_engine - sqlserver, postgresql, oracle, mysql, ...
- database_engine vs db_engine to be consistent with database name, schema name, etc

0. make sure namespace is a 4 tuple path with instance as a discrete component vs blended with system name
- system instance should be a standalone item and default to 01
- system instance can have sdlc or ods type wording
- drop udp prefix on schema names since all schemas will be udp content
- udp system vs data source table schemas (like udp_admin) will keep udp prefix

0. include region name in account aliases or s3 buckets ???
MMG: bucket names should be independent of region ???
- udp-aws-s3-amc-prod       <-- current
- udp-aws-usw2-s3-amc-prod  <-- proposed
- udp-aws-use1-s3-amc-prod  <-- place stratton bucket on east region (us-east-1)?

###

Capture - archive - stage code

0. Read template definitions from a udp.template file formatted using #define <name>
- read and walk through *.template defined SQL templates
- *.template file will allow us to remove hard coded {tab}'s but not hardcoded {indent()}'s
- {tab} and {indent()} are for beautification only and not required

0. Make sure all non-#temp table names are fully qualified with <database>.<schema>.<table> !!!!
- #temp tables are specific to connection so can be just #<table> name

1. python-list: how to expand f-strings in a variable vs a literal, eg. we want to read f-strings from config files
- SOLUTION: use eval() wrapper function to expand
- SOLUTION: local_vars = sys._getframe(1).f_locals (UBS common_lib.py to walk call stack to get caller's locals()

2. python-list: how to manage secrets
- via environ vars, private config file, commercial vault service, other?
- SOLUTION: use private config file; environ vars not always private

3. make sure table existence test specifies database.schema.table, not just table
- SOLUTION: One of these formats below; the N'u' or N'U' means *user* defined table
- if object_id(N'{qualified_table_name}', N'u') is null
- if object_id(N'{database_name}.{schema_name}.{table_name}', N'u') is null
- if object_id(N'udp_staging.amc_rtp_01_sales.closeheader', N'u') is null
- if object_id(('{database_name}.#{table_name}', N'u') is null
- begin ...; end;

4.


###

Capture

If cdc_type == drop, then
- pass through *.def
- create empty *.csv file (for consistency, will be ignored/trumped by cdc_type = drop

After capture cycle complete, if successful
- remove dropped table entries from *.history
- rename dropped *.def files *.dropped

###

Staging

test by calling schedule on history, once a day from start to current

input: resort, app, instance, subject, job
input: capture.zip

connect to staging

staging_runtime_start = now()
create schema if not exists

# set a marker in schema indicating job is running - prevent duplicate runs
if exists table _job_running:
	abort (until problem fixed and this table cleared)
else:
	create table _job_running ( job bigint, start_time datetime, message_blob )
	insert into _job_running ( job, now(), '' )
	commit

begin trans

verify job is next in sequence, otherwise abort and set _job_running.message_blob = 'out of sequence job'
get udp_nstpk (namespace table key)

unzip capture
compare source to target tables
if source table missing, abort - future: check for a drop table command or table.def property setting = drop/ignore/skip
ok if target table missing, we'll create it

drop #job_stats if exists
create #job_stats

drop #table_stats if exists
create #table_stats

for table in tables
	create (target) table if not exist (even if we have no updates on our first pass)

	if table has cdc_type == drop
		drop table

	elif table had no updates
		table_runtime = 0
		staging_inserts, staging_updates = 0
	else
		truncate #table_stats
		table_runtime_start = now()
		drop #table if exists
		create #table
		insert into #table
		update #table set <calculated columns>

		if cdc_type == replace (ref data or tables without cdc attributes)
			# TODO: Add option for replace-and-save (saves existing pk/guids) or just replace (recreates)
			# TODO: Rewrite below as a load to #temp, calculate udp_nstpk, udp_nk, udp_timestamp of capture job
			# TODO: We need #temp to have udp_nk so we can match udp_pk's we want to save
			save udp_nk, udp_pk
			identity_restart = max(udp_pk) + 1
			drop target table if exists
			create target table with udp_pk as non-identity
			insert udp_nk matches into target table
			alter target udp_pk identity(identity_restart, 1)
			insert non-udp_nk matches into target table
			update target set
				udp_guid = cast(varchar, udp_nstpk) + '-' + cast(varchar, udp_pk),
				udp_timestamp = capture_timestamp from *.history file or capture job start time

			summarize #table_stats into staging_inserts = count(*), staging_updates = 0
		else
			merge table using #table
			collect merge output for #table_stats
			summarize #table_stats into staging_inserts, staging_updates

		table_runtime_end = now()
		table_runtime = table_runtime_end - table_runtime_start

	insert table_runtime, staging_inserts, staging_updates, table drops (and dropped rec count) into #job_stats

summarize job_stats by table insert/update
update udp_admin.table_log (job, udp_nstpk, staging_inserts, staging_updates, staging_runtime, staging dropped records via table drop)

staging_runtime_end = now()
staging_runtime = staging_runtime_end - staging_runtime_start

if all steps pass, then commit
if error, rollback, then log problem in _job_running.message, exit

begin trans
	# stage = capture, archive, stage, unify, master ... mart (and master?) may run separately and independently ???
	update udp_admin.job_log (job, stage, udp_nsk, start_time, end_time, duration, status, diagnostics_blob (if failed))

if all steps pass, then commit - clear job running status via drop table _job_running
if error, rollback, then log problem in _job_running

"""


import pyodbc
import sys


tab = '\t'
newline = '\n'


def out(value):
	print(str(value) + '\n')


def expand(expression):
	# reach up call stack to get callers locals() dict

	# noinspection PyProtectedMember
	caller_locals = sys._getframe(1).f_locals
	triple_quote = "'" * 3
	expression = dedent(expression)
	return eval(f'f{triple_quote}{expression}{triple_quote}', None, caller_locals)


def indent(text, tab_count=1):
	"""Indent each line with tab_count tabs."""

	lines = list()
	for line in text.splitlines():
		line = '\t' * tab_count + line.strip()
		lines.append(line)

	# return indented lines
	return '\n'.join(lines)


def dedent(text):
	"""Strip leading tab indentation from all lines in text."""
	return '\n'.join(line.strip() for line in text.splitlines())


def connect():
	# db_server = 'udp-powerbi-sandbox.c4yiy3ssz15k.us-west-2.rds.amazonaws.com'
	db_server = 'udp-powerbi-sandbox.alterramtnco.com'
	db_database = 'Sandy'
	db_user = 'udp_powerbi_sandbox_admin'
	db_pass = 'PastrySportAnywhere'

	# setup
	print(f'pyodbc version: {pyodbc.version}')
	print(f'odbc drivers: {pyodbc.drivers()}')
	pyodbc.lowercase = True
	db_connection = list()

	# if you are running on Windows, you can just use the native driver: driver={SQL Server}
	# Note: Use driver={SQL Server} in non-Windows (Linux/MacOS) environments.
	# Note: Latest driver=ODBC Driver 17 for SQL Server;
	db_connection.append('driver={ODBC Driver 13 for SQL Server}')
	db_connection.append(f'server={db_server}')
	db_connection.append(f'database={db_database}')

	# use trusted_connection -OR- user/password (these are mutually exclusive options)
	# db_connection.append('trusted_connection=yes')
	db_connection.append(f'uid={db_user}')
	db_connection.append(f'pwd={db_pass}')

	# create the connection
	db_connection_str = '; '.join(db_connection)
	conn = pyodbc.connect(db_connection_str)
	conn.autocommit = False

	return conn

# --- sql templates

# TODO: SQL to:
# create udp_staging database if not exists
# create udp_admin schema if not exists (located in udp_staging by intention)
# create tables: udp_nstpk, udp_job, udp_table if not exists

select_table_schema_sql = '''
select *
    {tab}from {database_name}.information_schema.columns 
	{tab}where
    {tab}{tab}table_catalog = N'{database_name}' and 
    {tab}{tab}table_schema = N'{schema_name}' and 
    {tab}{tab}table_name = N'{table_name}';
'''



# capture select
# TODO: 4 scenarios
# Note: last timestamp/rowversion is based on history file and if not present first_timestamp/rowversion in *.def file
#
# 1 - basic select based on a single timestamp - get last_timestamp, current_timestamp
# 2 - basic select based on max( multiple timestamps ) - get last_timestamp, current_timestamp
# 3 - basic select based on a rowversion - get last_rowversion, current_rowversion
# 4 - pull entire table as a drop and replace (a generic alternative to truncate and reload, drop and replace)
# After all tables captured, update history with each table's new current_timestamp/rowversion
# After drop and replace tables captured, update *.def file with column_definitions ??? !!!
#
select_sql = '''
select *, {job} as job
	{tab}from {qualified_table_name}
	{tab}where {row_timestamp} between {last_time} and {current_time}
'''.strip()

create_table_sql = '''
if object_id(N'{database_name}.{schema_name}.{table_name}', N'u') is null
begin
	{tab}-- table doesn't exist
	{tab}create table {qualified_table_name} (
		{indent(base_column_definitions, 2)},
		{indent(capture_column_definitions, 2)}
		{indent(staging_column_definitions, 2)}
	{tab});
end;
'''.strip()


# TODO: If cdc_type == 'replace' then we need to discover columns, type, null, etc fill in <table>.def
# Replace type tables should update their *.def table file every time. We pass these *.def files
# to staging where we open up to create #temp tables, missing target tables, merge statements, etc

# calculate udp_* columns in temp table using values after import conversion using target database engine
update_1_sql = '''
update #{table_name} set
	udp_nk = {nk_expression},
	udp_nstpk = {},
	udp_row_timestamp = '{row_timestamp}',
	udp_row_version = {row_version};
'''

# update udp_guid's for all records affected by current job
update_2_sql = '''
update {qualified_table_name} set
	udp_guid = cast(varchar udp_nstpk) + '-' + cast(varchar udp_pk)
	where udp_jobid = {job};
'''


merge_sql = '''
-- merge (upsert) source into target table
merge {qualified_table_name} as t
	{tab}using #{table_name} as s
	{tab}on t.udp_nk = s.udp_nk
when matched by target then
	{tab}-- must have explicit list of columns
	{tab}update set {column_source_assignments_str}
when not matched then
	{tab}-- must have explicit list of columns
	{tab}insert ({column_names_str})
	{tab}values ({column_names_source_aliased_str})
'''.strip()


capture_column_definitions = '''
-- udp capture columns
udp_jobid int not null,
'''

staging_column_definitions = '''
-- udp staging columns
udp_pk bigint identity(1,1),
udp_nk nvarchar(128),
udp_nstpk int,
udp_guid varchar(32),
udp_rowtimestamp datetime,
udp_rowversion bigint
'''


# --- table specific

# source columns
column_definitions = '''
closeid nvarchar(32) not null
auditlocationcode int null
clientcode int null
closedate datetime null
closecomment nvarchar(max) null
processflag int null
remotecloseclientcode int null
bagnumber nvarchar(32) null
operatorid nvarchar(255) null
updatedate datetime null
'''.strip()

# add trailing commas to column definitions
base_column_definitions = ',\n'.join(column_definitions.splitlines())

database_name = 'udp_staging'
schema_name = 'udp_amc_rtp01_sales'
table_name = 'closeheader'
qualified_table_name = f'{database_name}.{schema_name}.{table_name}'
row_timestamp = 'updatedate'
row_version = 0

job = 333
udp_nstpk = 8
last_time = '2018-03-23T09:00'
current_time = '2018-03-23T10:00'

# row_timestamp = current_time

# --- generic processing

# capture code
sql = expand(select_sql)
out(sql)



# we have 3 types of table creates: stage, stage temp, and stage replace (vs merge)
# when creating #table: drop table if exists #{table_name};
# when processing a replace (ref table) vs timestamp/rowversion table: drop table if exists {table_name};
sql = expand(create_table_sql)
out(sql)

# column_names
column_names = list()
for line in base_column_definitions.splitlines():
	column_name = line.partition(' ')[0]
	if not column_name.startswith('--'):
		column_names.append(column_name)
column_names_str = ', '.join(column_names)

# source.column,
column_names_source_aliased = [f's.{column_name}' for column_name in column_names]
column_names_source_aliased_str = ', '.join(column_names_source_aliased)

# target.column = source.column,
column_source_assignments = [f't.{column_name} = s.{column_name}' for column_name in column_names]
column_source_assignments_str = ', '.join(column_source_assignments)

sql = expand(merge_sql)
out(sql)

sql = expand(select_table_schema_sql)
out(sql)

'''
# create table column specs for generating column definitions

column_name = lowercase column name
data_type = bigint, date, datetime, float, int, nvarchar, real, smallint, tinyint, varchar
is_nullable = YES (blank), NO (NOT NULL)

bigint, int, smallint, tinyint
decimal(numeric_precision, numeric_scale)
float, real
nvarchar|varchar(character_maximum_length); if character_maximum_length == -1, use 'max'
datetime|datetime2(datetime_precision)
'''

conn = connect()
cursor = conn.cursor()

# datetime: datetime2({datetime_precision}) (remap datetime to datetime2's?)
sql_server_data_types = '''
bigint: bigint
int: int
smallint: smallint
tinyint: tinyint

decimal: decimal({numeric_precision}, {numeric_scale})
float: float(53)
real: real

date:
datetime: datetime
datetime2: datetime2({datetime_precision})
time: time

nvarchar: nvarchar({max_length})
varchar: varchar({max_length})
'''.strip()

# convert data type mappings to template dict
sql_server_data_type_mappings = dict()
for line in sql_server_data_types.splitlines():
	line = line.strip()
	if not line:
		continue
	data_type, colon, data_type_template = line.partition(':')
	data_type = data_type.strip()
	data_type_template = data_type_template.strip()
	sql_server_data_type_mappings[data_type] = data_type_template

out(sql_server_data_type_mappings)

cursor.execute(sql)
for row in cursor:
	column_name = row.column_name
	numeric_precision = row.numeric_precision
	numeric_scale = row.numeric_scale
	datetime_precision = row.datetime_precision

	if row.character_maximum_length == -1:
		max_length = 'max'
	else:
		max_length = row.character_maximum_length

	if row.is_nullable == 'YES':
		nullable = ''
	else:
		nullable = ' not null'

	data_type  = expand(sql_server_data_type_mappings[row.data_type])
	column_definition = f'{column_name} {data_type}{nullable}'
	print(column_definition)
