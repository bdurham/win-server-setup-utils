# capture-2.py


import csv
import glob
import os
import sqlite3
import sys
import time

# common code
from udp_lib import *


"""
Separate capture utility for each data source - run in its own folder
Run a different NT Service for each capture script
Must name the capture scripts something unique to track them in Task Manager/Event Logs ???
"""


CHAR_NEWLINE = '\n'


def load_table_defs(file_name):
	with open(file_name) as input_stream:
		lines = input_stream.read()
	lines = lines + '\n#define ignore\n'

	table_defs = dict()
	table_name = ''
	table_code = ''
	for line in lines.splitlines():
		line = line.replace('\t', ' ').strip()

		if line.startswith('#define '):
			# add table name and code to dict
			if table_name:
				table_defs[table_name] = table_code.strip()

			# begin a new table name and code definition
			table_name = line.partition(' ')[2].strip().lower()
			table_code = ''
		elif line and not line.startswith('#'):
			# add line to current table code
			table_code = f'{table_code}{line}\n'
		else:
			# line is blank or a comment line (# comment ...)
			pass

	return table_defs


sql_create_job_database = '''
create table job (
	job_id integer primary key,
	source_code char(16),
	begin_timestamp datetime,
	end_timestamp datetime,
	start_time datetime,
	status_code char(16),
	status_details char(4096)
)
'''


def get_job_table_connection(job_database=''):
	"""Returns connection to job table database."""

	source_code = 'AMC-RTP-1'

	if not job_database:
		job_database = f'capture-{source_code}.db'

	if os.path.exists(job_database):
		conn = sqlite3.connect(job_database)
	else:
		conn = sqlite3.connect(job_database)
		cursor = conn.cursor()
		cursor.execute(sql_create_job_database)

	return conn


class CaptureLoop(EventLoop):

	def start(self):
		# read capture schedule times
		# read connection details - env strings, protected folder
		# read source name
		# read debug, trace, log options

		# take the folder name so every capture .config file is uniquely named by source
		self.table_defs = load_table_defs('capture.config')

	def time_to_capture(self):
		current_time = int(time.time())
		print(current_time)
		return current_time/5 == int(current_time/5) or not self.is_continue()

	def process(self):

		# check if its time to capture (could also look for a sentinel file to trigger)
		while self.is_continue():
			while not self.time_to_capture():
				print('Sleeping ...')
				time.sleep(1)

			if not self.is_continue():
				break

			print('Time to capture')
			time.sleep(1)
			for table_name, table_code in self.table_defs.items():
				# cursor.execute(table_code) - future: execute in friendly blocks of N records
				# print(f'''{table_name} = {table_code.replace(CHAR_NEWLINE, ' ')}''')
				pass


'''
* Increment job_id
* Read config file of table pull specs
* Build incremental pull query
* Pull records
* Save to staging/*.CSV
* Build zipfile_name (source+timestamp).zip
* Zip staging/* to zipfile_name
* Append log to zipfile_name
* Push zip file
'''


def main(*args):
	"""Main routine."""

	'''
	# create and run application object
	app = Application()
	app.run()
	'''

	# event_loop = EventLoop(is_traced=True)
	capture_loop = CaptureLoop(is_traced=True)
	capture_loop.run()

	version_info()


if __name__ == '__main__':
	main(*sys.argv[1:])
