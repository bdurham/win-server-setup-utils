# test_terraform_log_import.py

"""
Read a Terraform log file and create config override files to use Terraform output.

Future: Read Terraform JSON state file for values without having to depend on explict log file.

"""

import glob


'''
Analysis:

DONE: Global

NOT-USED: REGION: us-west-2
NOT-USED: IAM.aws_account.id = 859426443104  
NOT-USED: IAM.aws_account_alias = <MISSING>

...

DONE: Entity specific capture apps/projects 

NOT-USED: IAM.user_service_capture_amc.username = aws-udp-user-service-capture-amc-sandbox-sjg
USED: IAM.user_service_capture_amc.access_key = AKIAI6AD6JS2ANPHY7WA
USED: IAM.user_service_capture_amc.secret_key = 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
USED: S3.capture_amc_bucket.name = aws-udp-s3-capture-amc-sandbox-sjg

...

DONE: AWS UDP EC2 based apps (archive, stage, etc)

DONE: Role
NOT-USED: IAM.role_private_windows_server_application.name = aws-udp-role-private-windows-server-application-sandbox-sjg
USED: IAM.role_private_windows_server_application.arn = arn:aws:iam::859426443104:role/aws-udp-role-private-windows-server-application-sandbox-sjg

DONE: User (a temporary service account until role based authentication in place)
USED: IAM.user_mgreene.access_key = AKIAI6PHSJRZAF7PJXHQ
USED: IAM.user_mgreene.secret_key = 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

NOT-USED: S3.admin_bucket.name = aws-udp-s3-admin-sandbox-sjg
USED: S3.archive_bucket.name = aws-udp-s3-archive-sandbox-sjg
USED: SQS.capture_queue.name = aws-udp-sqs-capture-sandbox-sjg
USED: SQS.archive_queue.name = aws-udp-sqs-archive-sandbox-sjg
USED: SQS.stage_queue.name = aws-udp-sqs-stage-sandbox-sjg

...

DONE: RDS archive/stage

USED: RDS.mssql.address = aws-udp-rds-mssql-sandbox-sjg.cu86wwtmsair.us-west-2.rds.amazonaws.com
USED: RDS.mssql.master_username = aws_udp_user_master_sandbox_sjg
USED: RDS.mssql.master_password = AKIAJATDDRTCTL7MMERQ
USED: RDS.mssql.port = 49733

...

Manual operator logins

# AWS login
IAM.aws_account.sign_in_url = https://aws-udp-sandbox-sjg.signin.aws.amazon.com/console
IAM.user_mgreene.username = aws-udp-user-mgreene-sandbox-sjg
IAM.user_mgreene.password = Malcolm123@
IAM.user_mgreene.access_key = AKIAI6PHSJRZAF7PJXHQ
IAM.user_mgreene.secret_key = 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

# Jumpbox login - update RDP file with URL ???
# Assumes same username/password for target app server login
EC2.jumpbox.ipv4 = 52.36.98.162 <-- should be elastic IP
EC2.jumpbox_user_mgreene.password = Malcolm123@
EC2.jumpbox_user_mgreene.username = mgreene

'''


'''
Mapping to above:

# Cloud for entity capture (AMC) and UDP ETL 

udp.connect:[cloud_amc_aws_capture_01_etl_dev]
region = <Terraform:Region>
publickey = <Terraform:IAM.user_service_capture_amc.access_key>
privatekey = <Terraform:IAM.user_service_capture_amc.secret_key>

udp.connect:[cloud_udp_aws_archive_01_etl_dev]
region = <Terraform:Region>
role = <Terraform:IAM.role_private_windows_server_application.name>
publickey = <Terraform:IAM.user_mgreene.access_key>
privatekey = <Terraform:IAM.user_mgreene.secret_key>

# Note: We could also clone this value vs duplicate it.
udp.connect:[cloud_udp_aws_stage_01_etl_dev]
region = <Terraform:Region>
role = <Terraform:IAM.role_private_windows_server_application.name>
publickey = <Terraform:IAM.user_mgreene.access_key>
privatekey = <Terraform:IAM.user_mgreene.secret_key>

...

# RDS for UDP ETL
udp.connect:[database_udp_aws_stage_01_datalake_dev]
host = <Terraform:RDS.mssql.address> 
port = <Terraform:RDS.mssql.port>
username = <Terraform:RDS.mssql.master_username>
password = <Terraform:RDS.mssql.master_password>

...

# overrides for AWS resource names

Note: We currently add SDLC suffixes to S3 buckets (required) and SQS queues (not required)
Note: Using queue URL's would allow us to use cross account queues if we wanted, but why would we do this with queues?
Note: We use actual resource names vs deriving names based on <entity> and <sdlc>

amc_heroku_amp_01_sales_dev.project:[capture_project]
amc_sungard_rtp_01_sales_dev.project:[capture_project]
amc_sungard_dlakeref_01_sales_dev.project:[capture_project]
; cloud = cloud_amc_aws_capture_01_etl_dev
capture_objectstore = <Terraform:S3.capture_amc_bucket.name>

udp_aws_archive_01_etl_dev.project:[archive_project]
; cloud = cloud_udp_aws_archive_01_etl_dev
; database = database_udp_aws_stage_01_datalake_dev
archive_objectstore = <Terraform:S3.archive_bucket.name> 
capture_queue = <Terraform:SQS.capture_queue.name> 

udp_aws_stage_01_etl_dev.project[stage_project]
; cloud = cloud_udp_aws_stage_01_etl_dev
; database = database_udp_aws_stage_01_datalake_dev
archive_objectstore = <Terraform:S3.archive_bucket.name> 
archive_queue = <Terraform:SQS.archive_queue.name>
stage_queue = <Terraform:SQS.stage_queue.name>

'''

# test code
def main(input_file=None):

	# read Terraform log file settings
	input_file = 'terraform.log'
	terraform_settings = dict()
	with open(input_file) as input_stream:
		# read all key=value pairs; ignore other lines
		for line in input_stream:
			if '=' in line:
				key, separator, value = line.partition('=')
				key = key.strip().lower()
				value = value.strip()
				terraform_settings[key] = value

		print('\nTerraform settings:')
		for key, value in terraform_settings.items():
			print(f'{key} = {value}')

	# read Terraform map file [section] key = <Terraform:key> settings
	input_file = 'terraform.map'
	terraform_mappings = dict()

	section_name = ''
	with open(input_file) as input_stream:
		# read all key=value pairs; ignore other lines
		for line in input_stream:
			# skip blank and comment lines
			line = line.strip()
			if not line or line.startswith(('#', ';', '/')):
				continue

			if line.startswith('[') and line.endswith(']'):
				section_name = line.lstrip('[').rstrip(']').strip().lower()

			# line is a key=value pair
			elif '=' in line:
				key, separator, value = line.partition('=')
				key = key.strip().lower()
				value = value.strip().lower()
				terraform_key = value.replace('<terraform:', '').rstrip('>')
				if terraform_key in terraform_settings:
					terraform_mappings[f'{section_name}:{key}'] = terraform_settings[terraform_key]
				else:
					print(f'Unknown terraform key: {terraform_key}')

			# ignore line
			else:
				pass

		print('\nTerraform mappings:')
		for key, value in terraform_mappings.items():
			print(f'{key} = {value}')


# test code
if __name__ == '__main__':
	main()
