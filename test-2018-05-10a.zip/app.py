#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Common app shell for all standalone scripts.
Daemonized scripts should import daemon framework for core logic.

trace()
log()
stats() - start time, runtime-to-date
version() - python, windows, sql_server, external libs/adapters
status()
config() - command line, env vars, config files
exception() - append to *.err

"""


# app
import datetime
import pathlib
import sys
import traceback


class App:

	def __init__(self):
		self.trace_flag = False
		self.script_name = pathlib.Path(sys.argv[0]).stem

	def run(self, *args, **kwargs):
		# noinspection PyBroadException
		try:
			self.setup(*args, **kwargs)
			self.main()
			self.cleanup()
		except Exception:
			self.unhandled_exception()

	def unhandled_exception(self):
		output_file_name = self.script_name + '.err'
		try:
			with open(output_file_name, 'a') as output_stream:
				# output_stream.write(f'Unhandled exception: {e}\n')
				output_stream.write(f'{datetime.datetime.now().isoformat()}\n')
				traceback.print_exc(file=output_stream)
				output_stream.write('\n')

		except IOError:
			pass

	def trace(self, message):
		if self.trace_flag:
			print(message)

	def setup(*args, **kwargs):
		pass

	def main(self):
		pass

	def cleanup(self):
		pass


# test code
class TestApp(App):

	@staticmethod
	def force_error():
		# raise BytesWarning('Custom exception message', 1, 2, 3)
		open('').read()

	def main(self):
		self.trace_flag = True
		self.trace(f'Script: {self.script_name}')
		# self.force_error()


# test code
def main():
	test_app = TestApp()
	test_app.run()


# test code
if __name__ == '__main__':
	main()
