# import boto3
# import pyodbc


class Trace:

	def trace(self, message):
		if not hasattr(self, 'trace_flag'):
			self.trace_flag = False
		if self.trace_flag:
			print(message)

class Base:
	pass


class Test(Base, Trace):

	def __init__(self):
		self.trace_flag = True
		print('In init')
		self.trace('Tracing in init')

# testing multiple inheritance
test = Test()

