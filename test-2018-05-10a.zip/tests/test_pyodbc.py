#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Test pyodbc with AWS RDS Sandbox SQL Server.
"""


# test_pyodbc
import pyodbc


# use cname version of server when available
# db_server = 'udp-powerbi-sandbox.c4yiy3ssz15k.us-west-2.rds.amazonaws.com'
db_server = 'udp-powerbi-sandbox.alterramtnco.com'
db_database = 'Sandy'
db_user = 'udp_powerbi_sandbox_admin'
db_pass = 'PastrySportAnywhere'

# setup
db_connection = list()

# if you are running on Windows, you can just use the native driver: driver={SQL Server}
# Note: Use driver={SQL Server} in non-Windows (Linux/MacOS) environments.
db_connection.append('driver={ODBC Driver 13 for SQL Server}')
db_connection.append(f'server={db_server}')
db_connection.append(f'database={db_database}')

# use trusted_connection -OR- user/password (these are mutually exclusive options)
# db_connection.append('trusted_connection=yes')
db_connection.append(f'uid={db_user}')
db_connection.append(f'pwd={db_pass}')

# pyodbc version
print(f'pyodbc version: {pyodbc.version}')

# create the connection
db_connection_str = '; '.join(db_connection)
conn = pyodbc.connect(db_connection_str)

# execute test SQL
cursor = conn.cursor()
cursor.execute("""
if object_id('customers', 'u') is not null
    drop table customers;

create table customers (
    id int not null,
    customer_name varchar(100),
    customer_note varchar(100),
    primary key(id)

);
""")


# data
rows = [
  (1, 'Ann', 'Ann note'),
  (2, 'Bob', 'Bob note'),
  (3, 'Cathy', 'Cathy note')
]

# noinspection SqlDialectInspection
cursor.executemany("insert into customers values (?, ?, ?)", rows)

# commit
conn.commit()

# noinspection SqlDialectInspection
cursor.execute("select * from customers where customer_name=?", 'Cathy')
for row in cursor:
    print("id=%d, name=%s" % (row[0], row[1]))

cursor.close()
conn.close()
