# test_background_thread.py

"""
This module is *REPLACED* by daemon.py which is simpler and doesn't require any threads.
"""


import os
import threading
import time


def safe_print(*args, **kwargs):
	lock = threading.Lock()
	with lock:
		print(*args, **kwargs)


class Heartbeat:

	def __init__(self, frequency, *args, **kwargs):
		self.lock = threading.Lock()
		self.frequency = frequency
		self.setup(*args, **kwargs)
		self.thread = threading.Timer(self.frequency, self.thread_body)
		self.thread.start()

	def thread_body(self):
		self.continue_flag = True
		while self.continue_flag:
			time.sleep(self.frequency)
			self.process()
		self.cleanup()

	def stop(self):
		self.continue_flag = False

	def setup(self, *args, **kwargs):
		"""Override:"""
		pass

	def cleanup(self, *args, **kwargs):
		"""Override:"""
		pass

	def process(self):
		"""Override:"""
		pass


class Command_Monitor(Heartbeat):

	def setup(self, cmd_file):
		safe_print(f'Starting command monitor ({cmd_file}) ...')
		self.cmd_file = cmd_file
		self.cmd = ''

	def cleanup(self):
		safe_print('Stopping command monitor ...')

	def set_cmd(self, value):
		with self.lock:
			self.cmd = value

	def get_cmd(self):
		with self.lock:
			# retrieve command
			cmd = self.cmd

			# then clear it
			self.cmd = ''
		return cmd

	def query_cmd(self):
		if os.path.exists(self.cmd_file):
			with open(self.cmd_file) as input_stream:
				cmd = input_stream.readline()
				cmd = cmd.strip().lower()
				self.set_cmd(cmd)
			os.remove(self.cmd_file)

	def process(self):
		self.query_cmd()


class AppExit (Exception):
	pass


class AppRestart(Exception):
	pass


def check_status(command_monitor):
	cmd = command_monitor.get_cmd()

	if cmd == 'pause':
		safe_print(f'Detected cmd: {cmd}')
		while True:
			time.sleep(command_monitor.frequency)
			cmd = command_monitor.get_cmd()
			if cmd in ['stop', 'restart', 'continue']:
				break
			elif cmd:
				safe_print(f'Detected cmd: {cmd} (while paused)')

	if cmd:
		safe_print(f'Detected cmd: {cmd}')

	if cmd == 'stop':
		raise AppExit
	elif cmd == 'restart':
		raise AppRestart


def do_work(command_monitor):
	time.sleep(0.5)
	check_status(command_monitor)


command_monitor = Command_Monitor(0.5, 'test.cmd')

app_not_stopped = True
while app_not_stopped:
	safe_print('(Re)starting app ...')
	app_not_restarted = True

	try:
		while app_not_restarted:
			do_work(command_monitor)

	except AppRestart as e:
		app_not_restarted = False

	except AppExit as e:
		app_not_stopped = False


command_monitor.stop()
safe_print('Exiting app ...')

