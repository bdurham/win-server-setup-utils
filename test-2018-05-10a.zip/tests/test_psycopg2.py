# test_psycopy2.py


"""
UserWarning: The psycopg2 wheel package will be renamed from release 2.8.
Ref: http://initd.org/psycopg/docs/install.html#binary-install-from-pypi

In order to keep installing from binary use the following instead:

pip install psycopg2-binary
"""

import psycopg2


class Config:
	"""General purpose object built to hold on-demand properties."""
	pass


def setup_amp_uat():
	"""AMP UAT via PostgreSQL"""
	config = Config()
	config.resort = 'amc'
	config.system = 'amp01'
	config.subject = 'sales'
	config.db_server = 'ec2-34-230-153-80.compute-1.amazonaws.com'
	config.db_port = 5432
	config.db_database = 'dcdc9r2tplv9f'
	config.db_user = 'alterra-data-lake-uat'
	config.db_pass = 'p933dbd025533bd4a7bfb4cb53a7bf16bac7112926df2d853e91a21beb951efc2'
	return config


def setup_amp_prod():
	"""AMP PROD via PostgreSQL"""
	config = Config()
	config.resort = 'amc'
	config.system = 'amp01'
	config.subject = 'sales'
	config.db_server = 'ec2-34-237-251-222.compute-1.amazonaws.com'
	config.db_port = 5432
	config.db_database = 'db6oacl4dfhph7'
	config.db_user = 'alterra-data-lake'
	config.db_pass = 'p987e2b5f61d113247839010c38d6dea1287605205f47f7979a3057459bc4ea23'

	return config


# test code
def main():
	# example: dbname=test user=postgres password=secret"
	# host – database host address (defaults to UNIX socket if not provided)
	# port – connection port number (defaults to 5432 if not provided)
	# dbname – the database name (database is a deprecated alias)
	# user – user name used to authenticate
	# password – password used to authenticate

	config = setup_amp_uat()
	# config = setup_amp_prod()
	db_connection = f'host={config.db_server} dbname={config.db_database} user={config.db_user} password={config.db_pass}'
	print(db_connection)

	conn = psycopg2.connect(db_connection)
	cursor = conn.cursor()
	cursor.execute('select version();')
	row = cursor.fetchall()
	print(row[0][0])
	cursor.execute('select * from guests limit 10;')
	rows = cursor.fetchall()
	for row in rows:
		print(row)
	conn.close()


# test code
if __name__ == '__main__':
	main()
