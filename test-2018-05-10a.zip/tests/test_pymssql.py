#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Test pymssql with AWS RDS Sandbox SQL Server.
"""


# test_pymssql
import pymssql


# db_server = 'udp-powerbi-sandbox.c4yiy3ssz15k.us-west-2.rds.amazonaws.com'
db_server = 'udp-powerbi-sandbox.alterramtnco.com'
db_database = 'Sandy'
db_user = 'udp_powerbi_sandbox_admin'
db_pass = 'PastrySportAnywhere'

conn = pymssql.connect(db_server, db_user, db_pass, 'sandy')
cursor = conn.cursor()
cursor.execute("""
if object_id('customers', 'u') is not null
    drop table customers;

create table customers (
    id int not null,
    customer_name varchar(100),
    customer_note varchar(100),
    primary key(id)

);
""")


# data
rows = [
  (1, 'Ann', 'Ann note'),
  (2, 'Bob', 'Bob note'),
  (3, 'Cathy', 'Cathy note')
]

# noinspection SqlDialectInspection
cursor.executemany("insert into customers values (%d, %s, %s)", rows)

# commit
conn.commit()

# noinspection SqlDialectInspection
cursor.execute("select * from customers where customer_name=%s", 'Cathy')
for row in cursor:
    print("id=%d, name=%s" % (row[0], row[1]))

cursor.close()
conn.close()
