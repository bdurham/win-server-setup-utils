#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
UDP platform code.
"""

# udp.py

# udp libs
import config
import database


# global names
udp_stage_database = 'udp_stage'
udp_catalog_schema = 'udp_catalog'

def setup():
	# TODO: Create a project file for all udp cloud based ETL scripts (archive, stage, udp, etc)
	database_connect_name = 'database_aws_etl_dev'
	cloud_connect_name = 'aws_udp_etl_dev' # TODO: should be cloud_aws_etl_dev !!!

	# SQL Server
	connect_config = config.Config('config/udp.connect', config.ConnectionSection)
	connect_config.dump()
	sql_server_connect = connect_config.sections[database_connect_name]

	# TODO: should read 'sqlserver' as an engine property from udp.connect
	# TODO: debug should also enable/disable sql output and timing/record count stats
	db = database.SQLServerConnection(sql_server_connect, debug=True)
	conn = db.conn
	cursor = conn.cursor()
	db_conn = database.Database('sqlserver', conn)

	# create data stage database if not present; then use
	db_conn.create_database(udp_stage_database)
	db_conn.use_database(udp_stage_database)

	# create data catalog schema if not present
	db_conn.create_schema(udp_catalog_schema)

	# create data catalog tables if not present
	db_conn.create_named_table(udp_catalog_schema, 'nst_lookup')
	db_conn.create_named_table(udp_catalog_schema, 'job_log')
	db_conn.create_named_table(udp_catalog_schema, 'table_log')
	db_conn.create_named_table(udp_catalog_schema, 'table_log')
	db_conn.create_named_table(udp_catalog_schema, 'stage_arrival_queue')
	db_conn.create_named_table(udp_catalog_schema, 'stage_pending_queue')


# test code
def main():
	setup()


# test code
if __name__ == '__main__':
	main()
